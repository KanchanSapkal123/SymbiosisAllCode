package Encapsulation;

import com.model.*;



public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Address a=new Address(1369,"pune","india");
		
		Employee e=new Employee(1,"kanchan",600000);
		System.out.println(e);
		
		e.setId(2);
		e.setName("abc");
		e.setSalary(600000);
		
		System.out.println(e);
		
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		
		System.out.println(a.getPinCode()+" "+a.getCity()+" "+a.getCountry());
		
		
		
		
	}

}
