package Encapsulation;


 class Employee {
	
private int id;
private String name;
private int Salary;
private Address address;


public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getSalary() {
	return Salary;
}


public void setSalary(int salary) {
	Salary = salary;
}
Employee(){
	
}



Employee(int id,String name,int salary)
{
	
	this.id=id;
	this.name=name;
	this.Salary=salary;
	
	
	
}

public String toString() 
{
	return id+" "+name+" "+Salary;
	
}

public int getId() {
	// TODO Auto-generated method stub
	return id;
}


 }
 
public class TestEmployee {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e=new Employee(1,"kanchan",600000);
		System.out.println(e);
		
		e.setId(2);
		e.setName("abc");
		e.setSalary(600000);
		
		System.out.println(e);
		
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		
		
	}

}
