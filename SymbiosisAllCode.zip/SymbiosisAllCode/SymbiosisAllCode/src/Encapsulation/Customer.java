package Encapsulation;


public class Customer {

	private int id;
	private String name;
	private int AdharNumber;
	private int email;
     private String password;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAdharNumber() {
		return AdharNumber;
	}

	public void setAdharNumber(int adharNumber) {
		AdharNumber = adharNumber;
	}
	
	public int getEmail() {
		return email;
	}

	public void setEmail(int email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	public static void main(String[] args) {
	
		Customer c=new Customer(1,"kanchan",99669191,kss);
		
		
		

	}

}
