


	
	
	
public class Recurstion {
	
	private	static void fact(int num, int factorial)
	{
		int fatorial = 1;
		for(int i=0;i<=num;i++) {
		 factorial = factorial*num;
		}
		
		System.out.println(factorial);
		
		
		return;
		
	}
	
	
	
	public static void main(String[] args) {
	


		fact(2,3);
		

}
}