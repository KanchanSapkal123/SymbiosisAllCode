import java.util.Scanner;

public class TestFibbonacciSerease {

	public static void main(String[] args) {
		
		
		       
		        Scanner input = new Scanner(System.in);

		  
		        System.out.print("Enter the number of terms: ");
		        int nTerms = input.nextInt();

		    
		        int n1 = 0, n2 = 1;

		        if (nTerms <= 0) {
		            System.out.println("Please enter a positive integer.");
		        }
		        else if (nTerms == 1) {
		            System.out.println("Fibonacci series up to " + nTerms + ":");
		            System.out.println(n1);
		        }
		        else {
		            System.out.println("Fibonacci series:");
		     
		            System.out.print(n1 + " " + n2 + " ");
		 
		            for (int i = 3; i <= nTerms; i++) {
		                int nth = n1 + n2;
		                System.out.print(nth + " ");
		       
		                n1 = n2;
		                n2 = nth;
		            }
		        }
		    }
		
		
		
		
	}


