package Loop;

public class TestForLoop_Reverse_10_to_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    //reverse order 10 to 1
		
		for(int i=10;i>=1;i--) 
		{
			System.out.println(i);
		}
	}

}
