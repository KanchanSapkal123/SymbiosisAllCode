package Loop;

import java.util.Scanner;

public class TestForLoop_Addition {

	public static void main(String[] args) {
		// 
		
		int num;
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=5;i++) {
		num=sc.nextInt();
		System.out.println("");
		
	
		
		}

	}

}