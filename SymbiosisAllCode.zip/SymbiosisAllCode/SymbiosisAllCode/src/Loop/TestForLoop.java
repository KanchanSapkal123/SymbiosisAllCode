package Loop;

public class TestForLoop {

	public static void main(String[] args) {
		
		//WAP TO PRINT YOUR NAME 10 TIME
		
		for(int i=0;i<=10;i++)
		{
			System.out.println("kanchan");
		}
		
	}

}
