package Loop;

import java.util.Scanner;

class Testwhile
{
	int i,sum=1;
	
	Scanner sc=new Scanner(System.in);
	void input()
	{
		System.out.println("Enter number : ");
		i=sc.nextInt();
	}
	
	void checkCondition()
	{
		for(i=1;i<=5;i++) 
		{
			
		sum*=i;
		
		System.out.println(+sum);
}
}
}


public class Multiplication_By_For_Loop 
{

	public static void main(String[] args)
	{
		
		Testwhile t=new Testwhile();
		
		t.input();
		t.checkCondition();

	}

}
