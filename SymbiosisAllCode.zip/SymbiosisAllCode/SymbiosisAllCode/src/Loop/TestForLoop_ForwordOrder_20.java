package Loop;

public class TestForLoop_ForwordOrder_20 {

	public static void main(String[] args) {

		for(int i=2;i<=20;i=i+2) 
		{
			System.out.println(i);
		}

	}

}
