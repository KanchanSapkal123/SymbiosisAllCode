package Loop;

import java.util.Scanner;

public class TestForLoop_1_5_number_save {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		int sum = 0;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number : ");
		
		for(int i=1;i<=5;i++)
		{
			
			int num = sc.nextInt();
			sum+=num;    //sum=sum+i
		}
		
		System.out.println("sum is : "+sum);
		
	}

}
