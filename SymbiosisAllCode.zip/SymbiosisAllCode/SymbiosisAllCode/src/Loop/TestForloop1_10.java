package Loop;

public class TestForloop1_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1 to 10
		
		for(int i=1;i<=10;i++) 
		{
			System.out.println(i);
		}
		
		
	}

}
