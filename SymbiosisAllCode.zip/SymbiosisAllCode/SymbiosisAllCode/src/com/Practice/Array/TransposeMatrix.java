package com.Practice.Array;

import java.util.Scanner;

class TrMtrix
{
	Scanner sc=new Scanner(System.in);
	int row ,col;
	int[][] input()
	{
		System.out.println("Enter an row element : ");
		row=sc.nextInt();
		
		System.out.println("Enter an column element : ");
		col=sc.nextInt();
		
		int arr[][]=new int[4][4];
		
		return arr ;
		
	}

	int[][] display(int arr[][])
    {
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sc.nextInt();
				
			}
		}
		
		                                               
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println(arr[i][j]);
				
			}
		}
		System.out.println("main logic Transepose Array : ");
	
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println(arr[j][i]+" ");
				
			}
			System.out.println(  );
		}
		return arr;
		
	}

	public void display() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}



public class TransposeMatrix
{

	public static void main(String[] args)
	{
	
		TrMtrix t=new TrMtrix();
		t.input();
		t.display();
		

	}

}
