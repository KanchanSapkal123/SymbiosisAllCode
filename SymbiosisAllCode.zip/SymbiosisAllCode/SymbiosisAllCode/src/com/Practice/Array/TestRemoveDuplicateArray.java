package com.Practice.Array;

import java.util.*;

public class TestRemoveDuplicateArray {

	public static void main(String[] args) {

		int a[] = { 2, 20, 1, 10, 23, 2, 2 };

		Arrays.sort(a);

		int n = a.length;

		System.out.println("Before removal : ");
		
		
		for (int i = 0; i < n; i++) 
		{
			System.out.println("  " + a[i] + " ");
		}

		// System.out.print(" "+a[i]+" ");

		int temp[] = new int[n];

		int j = 0;

		
		for (int i = 0; i < n - 1; i++)
		{

			if (a[i] != a[i + 1]) 
			{
				temp[j] = a[i];
				j++;
			}
		}

		
		
		for (int i = 0; i < j; i++) 
		{
			a[i] = temp[i];
		}

		
		
		n = j;
		System.out.println("\nAfter removal : ");
		for (int i = 0; i < n; i++)
		{
			System.out.print(" " + a[i] + " ");
		}

	}
	
	

}
