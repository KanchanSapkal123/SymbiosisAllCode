package com.Practice.Array;

import java.util.Scanner;

class Matrix {
	int row, col;

	Scanner sc = new Scanner(System.in);
	
	int[][] input()
	{
		System.out.println("Enter row element : ");
		row = sc.nextInt();

		System.out.println("Enter coumn element : ");
		col = sc.nextInt();

		int arr[][] = new int[4][4];

		return arr;

	}

	
	int[][] interArray(int[][] arr)
	{
		System.out.println("Enter Element are Matrix : ");
		
		for (int i = 0; i < arr.length; i++) 
		{
             for(int j=0; j<arr[i].length;j++)
             {
            	 arr[i][j]=sc.nextInt();
             }
             System.out.println( );
		}

	
		
		for(int i=0;i<arr.length;i++) 
		{
			for(int j=0;j<arr[i].length;j++) 
			{
				System.out.println(arr[i][j]);
			}
			System.out.println();
		}
				return arr;
	}
	
	
	void check(int arr[][]) 
	{
		System.out.println("This is an main logic : ");

		int flag = 0;
		
		for(int i=0;i<arr.length; i++)
		{
			for(int j=0;j<arr.length;j++) 
			{
				
				if(i==j)
				{
					if(arr[i][j]!=1)
					{
						flag=0;
						break;
					}
					else
					{
						flag=1;
					}
				}
			}
		}
		
		if(flag==1) 
		{
			System.out.println("The matrix is an identity matrix : ");
		}
		else
		{
			System.out.println("the matrix is not identity matrix : ");
		}
		
	}
}

public class IdentityMatrix {

	public static void main(String[] args) {
	
		Matrix m=new Matrix();
		m.check(m.interArray(m.input()));
	}

}
