package com;

import java.util.Scanner;

public class ByUsingLoopConvertDesimalToBinary {

	public static void main(String[] args)
	{
		
		String b=" ";
		int n=9;
		int t=n;
		
		while(t>0) {
			
			int r= t%2;
		
			t= t/2;
			
			b= r + b;
			
		}
		
		System.out.println("Binary Equivalent of " +n+ " is : " +b);
		
		
	}
	}