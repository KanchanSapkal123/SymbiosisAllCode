package com;

import java.util.Scanner;

public class Pn { 

	
	Scanner sc=new Scanner(System.in);
	
	void input() 
	{
		int n;
		System.out.println("Enter number : ");
		n=sc.nextInt();	
		
		int m=n,s=0;
		
		for(int i=1;i<=n;i++) 
		{	
			if(n%1==0)
			{
				s=s+i;
				continue;	
		    }				
		}
		
           if(s==m)
           {
        	   System.out.println("This is the perfect number");
           }
           else 
           {
        	   System.out.println("This is not perfect number");

           }		
	}
	public static void main(String[] args) 
	{
		Pn p=new Pn();
		p.input();

	}

}
