package com;

import java.util.Scanner;

public class Perfectnumber {

	
	void findPerfect()
	{

		
    int n;

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number : ");
		
		 n=sc.nextInt();
		 
			int m=n,s=0;
			for(int i=1;i<=n;i++)
			{
			if(n%1==0)
			{
				s=s+i;
				continue;	
		    }		
			}	
			
			if(s==m)
			{
				System.out.println("perfect number : ");
			}
			else 
			{
				System.out.println("not perfect ");
			}
}
	public static void main(String[] args)
	{
		
		Perfectnumber p=new Perfectnumber();
		
		p.findPerfect();
		
	}

	}
