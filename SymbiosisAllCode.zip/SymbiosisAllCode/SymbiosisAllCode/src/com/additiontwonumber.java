package com;

public class additiontwonumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num =5,num2 = 6,result;
		
		result =num + num2;
		System.out.println(+result +" "+"is the result of " +num+"  and  " +num2);
	
	}
}
