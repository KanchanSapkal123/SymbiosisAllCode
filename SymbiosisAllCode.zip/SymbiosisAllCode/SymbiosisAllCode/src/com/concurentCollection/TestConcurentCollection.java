package com.concurentCollection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TestConcurentCollection {

	public static void main(String[] args) {
	

		ConcurrentHashMap<Integer,String> list = new ConcurrentHashMap<Integer,String>();

		list.put(102, "Ajay");
		list.put(102, "Vijay");
		list.put(103, "Sumit");
		list.put(104, "Amit");
		
		System.out.println(list);
		
		for (Map.Entry<Integer, String> m : list.entrySet()) 
		{
			list.put(105, "jay");                  //concorent allow to add new data member
			System.out.println(m.getKey() + " : ");
			System.out.println(m.getValue());
		}

		
		
		

	}

}
