package com.concurentCollection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class TestSyncronizedList {

	public static void main(String[] args) {
	
	List<String> list=new ArrayList<String>();
	
	list.add("Ajay");
	list.add("Vijay");
	list.add("Amit");
	list.add("Sumit");
	
	Collections.synchronizedList(list);
	
	synchronized(list)
	{
		Iterator<String> iterator=list.iterator();
		
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
	}
	
	}
}
/*

  
		       for(Integer al : l1) {
		    	   
		    	   System.out.println(al);
		       }
			
		    System.out.println("It.next returnn karta hay");
	          
		    //itarator
			Iterator<Integer> it = l1.iterator();//Iterator of list
			
			
			//what is hasNext()
			//what is next() method
			
			
			
			while(it.hasNext())
			{
				System.out.println("Iterator :"+it.next());
			}
			



*/