package com.Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

//import java.lang.reflect.Array;

public class Evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> list=new ArrayList<Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Element : ");
		int num=sc.nextInt();
		
		//input
		for(int i=0;i<=10;i++)
		{
			list.add(i);
		}
		
		System.out.println();
		
		//display
		
		System.out.println("Display Even Number : ");
		Iterator<Integer> iterator=list.iterator();
		
		while(iterator.hasNext()) {
			Integer n=iterator.next();
			if(n%2==0)
			{
				System.out.println(n);
			}
			
			
			
		}
	}

}
