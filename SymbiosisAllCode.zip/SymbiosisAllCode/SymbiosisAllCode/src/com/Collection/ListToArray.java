package com.Collection;

import java.util.*;

public class ListToArray {

	public static void main(String[] args)
	{
		
		List<String> list=new ArrayList<String>();
		
		
		list.add("Nikita");
		list.add("pranali");
		list.add("Kalyani");
		list.add("Sakshi");
		
		
		String arr[] =list.toArray(new String[list.size()]);
		
		System.out.println("List="+list);
		
		//System.out.println("List="+list);
		System.out.println("Array="+Arrays.toString(arr));
		
		System.out.println();
			
		
		
		}
}