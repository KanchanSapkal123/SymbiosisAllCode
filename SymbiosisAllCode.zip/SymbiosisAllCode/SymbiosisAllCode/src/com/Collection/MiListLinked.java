package com.Collection;

import java.util.*;

public class MiListLinked {

	public static void main(String[] args) {

		LinkedList<String> List = new LinkedList<String>();

		List.add("Ajay");
		List.add("Vijay");
		List.add("Amit");
		List.add("Sumit");
		List.add("null");

		
		//System.out.println(List);
		
		
		Iterator it=List.iterator();

		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	
		//String s="null";
		
	}

}
