package com.Collection;

import java.util.*;
import java.util.Queue;

public class TestQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	
		Queue<Integer> quIn=new LinkedList<Integer>();
		
		quIn.add(123);
		quIn.add(234);
		quIn.add(346);
		quIn.add(678);
		quIn.add(789);
		
		System.out.println("Element are : "+quIn);
		quIn.offer(234);
		quIn.offer(236);
		System.out.println(" offer elements : "+quIn);
		System.out.println(quIn.peek());
		quIn.poll();
		System.out.println("poll remove the elements : "+quIn);
		
		
		*/
		Queue<Integer> quIn2 = new PriorityQueue<Integer>();
		quIn2.add(11);
		quIn2.add(12);
		quIn2.add(13);
		System.out.println("Queue elment are : "+quIn2);
		quIn2.offer(14);
		System.out.println("After adding elements by offer method : "+quIn2);
		System.out.println(quIn2.peek());
		quIn2.poll();
		System.out.println("After removing  : "+quIn2);
		quIn2.poll();
		System.out.println("After removing2  : "+quIn2);

		//System.out.println("elment "+quIn2.element());
		
		
		
	}

}
