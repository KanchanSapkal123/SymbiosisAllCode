package com.Collection;

import java.util.*;


public class MiConvertArrayToString {

	public static void main(String[] args)
	{
		String a[]= {"Ajay","Vijay","Amit","Sumit"};
	
		
		System.out.println(Arrays.toString(a));
		
		/*
		for(int i=0;i<=3;i++)
		{
			System.out.println(a[i]);
		}
		*/
		List<String> list=new ArrayList<String>();
		
		for(String str:a)
		{
			list.add(str);
		}
		System.out.println("List="+list);
	}
	
	
	
	/*
	
String a[]={"Ajay" ,"Vijay","Amit",Sumit"};

	for(int i=0;i<=3;i++)
	{
	
	System.out.println(a[i])
	
	}
	
	List<String> l=new ArrayList<String>();
	
	for(String str:l)
	{
	     l.add(str)
	}
	
	*/
}