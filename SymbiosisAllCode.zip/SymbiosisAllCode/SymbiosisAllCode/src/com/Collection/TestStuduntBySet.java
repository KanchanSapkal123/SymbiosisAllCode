package com.Collection;

import java.util.*;
import java.util.Set;



//hashcode define uniqness

class Student13{
	private int roll_no;
	private String name;
	private String dept;
	//public String getroll_no();
	
	
	
	@Override
	public int hashCode() {
		return roll_no;
		
	}
	@Override
	public boolean equals(Object ob)
	{
		Student13 s=(Student13)ob;
		return roll_no==s.roll_no ;
		
	}
	
	
	
	Student13(int roll_no, String name, String dept)
	{
		this.roll_no=roll_no;
		this.name=name;
		this.dept=dept;
		
		
	}
	
	public int getRoll_no() 
	{
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Student13 [roll_no=" + roll_no + ", name=" + name + ", dept=" + dept + "]";
	}

}


public class TestStuduntBySet {

	public static void main(String[] args) {
		
		Set<Student13> sett=new HashSet<Student13>();
		sett.add(new Student13(101,"Ajay","MCA"));
		sett.add(new Student13(102,"vijay","BCA"));
		sett.add(new Student13(103,"Ajay","MCA"));
		sett.add(new Student13(104,"Ajay","MCA"));
		
		
System.out.println("HashSet : "+sett);
		
Iterator<Student13> iterator=sett.iterator();


while(iterator.hasNext()) 
{
	Student13  st=  iterator.next();
	System.out.println(st.getRoll_no()+" "+st.getDept());

}}

}
