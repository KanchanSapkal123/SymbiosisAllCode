package com.Collection;


import java.util.*;

public class MiList
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList list =new ArrayList();
		
		list.add("bhagyesh");
		list.add("ajay");
		list.add("vijay");
		list.add("Amit");
		list.add("null");
list.add(101);
		list.add(10);
		//Collections.sort(list);
		
	 
		
			System.out.println(list);
		
		
		
	}

}
