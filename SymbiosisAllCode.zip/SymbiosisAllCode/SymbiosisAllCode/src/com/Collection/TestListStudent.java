package com.Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



class Student
{
	
	
	private int id;
	private String name;
	private int salary;
	
	
	
Student(int id, String name, int salary)
{
		this.id=id;
		this.name=name;
		this.salary=salary;
}


public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}



public void  setId(int id)
{
	this.id=id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getId() {
	return id;
}

public String toString()
{
	return id+" "+name+" "+salary;
	
}
}


public class TestListStudent {

	public static void main(String[] args) {
	
		List<Student> list=new ArrayList<Student>();

		Student s1=new Student(1,"Ajay",10000);
		Student s2=new Student(2,"vijay",20000);
		Student s3=new Student(3,"amit",30000);
		
		list.add(s1);
		list.add(s2);
		list.add(s3);
		
		Iterator<Student> iterator=list.iterator();
		int total=0;
		while(iterator.hasNext()) //iterator point next element-->hasNext
		{
			Student s= iterator.next();
			int salary =s.getSalary();
			total=total+salary;
			System.out.println("Student : "+s);
		}
		System.out.println("Total Salary : "+total);
	}

}
