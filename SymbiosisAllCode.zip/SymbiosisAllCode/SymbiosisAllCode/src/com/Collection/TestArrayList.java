package com.Collection;
//WAP to print List of 10 number

import java.util.*;

public class TestArrayList{
	
	public static void main(String[] args)
	{
		
		//interface name  :: class name -->implementing
		//List<String> l=new ArrayList<String>();       //generic arrayList
		
		//ArrayList l=new ArrayList();           //it will give non generic elements 
		//Generic collection gives unified elements  ---->gives security
		
		
		ArrayList l=new ArrayList<>();//non generic arraylist
		
		//adding list of element
		
		l.add("Ajay");
		l.add("Vijay");
		l.add(123);
	
		
		System.out.println("non generic Array List Is : "+l);
		
		
		System.out.println("******************************************************************************");
		
		List<Integer> l1=new ArrayList<Integer>();
	       l1.add(1);
	       l1.add(2);
	       l1.add(1,14);
		System.out.println(l1);
		
	      //for each loop 
	       
	       
	       for(Integer al : l1) {
	    	   
	    	   System.out.println(al);
	       }
		
	    System.out.println("It.next returnn karta hay");
          
	    //itarator
		Iterator<Integer> it = l1.iterator();//Iterator of list
		
		
		//what is hasNext()
		//what is next() method
		
		
		
		while(it.hasNext())
		{
			System.out.println("Iterator :"+it.next());
		}
		
		List<Integer> list=new ArrayList<Integer>();
		
	//	list.addAll(l1);
	//	System.out.println(list);
		
		
		
		

	}

	
}
