package com.Collection;

import java.util.*;

public class TestHashSet {

	public static void main(String[] args) {

		Set<String> sett=new LinkedHashSet<String>();
		sett.add("delhi");
		sett.add("dubai");
		sett.add("mumbai");
		sett.add("pune");
		sett.add(null);
		System.out.println("Elements are : "+sett);
		System.out.println("**********************************************");
		Iterator iterator=sett.iterator();
		while(iterator.hasNext())
		{
			System.out.println("Iterator ="+iterator.next());
		}
		
		System.out.println("**************************************************");
		

		//ListIterator can not set,Queue and DeQueue
	}

}
