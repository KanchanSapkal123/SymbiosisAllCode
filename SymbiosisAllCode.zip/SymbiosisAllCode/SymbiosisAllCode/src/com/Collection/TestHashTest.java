package com.Collection;

import java.util.*;

//hash mab base on key value 

//map interface doese not access same element 
//and this are base key value

//why dose not
//Hash only access one null element 
//insertion removal and retrival  operation are perform

 
//dose not mentain order 
public class TestHashTest {

	public static void main(String[] args) {
		System.out.println("start  set concept");
		System.out.println("first topic HashSet");
		
		
		Set<Integer> sett =new HashSet<Integer>();
		
		sett.add(31);
		sett.add(32);
		sett.add(38);
		sett.add(30);
		sett.add(null);
		sett.add(null);
		System.out.println("Element are set : "+sett);
		System.out.println("***********************************************");
		Iterator<Integer> ite= sett.iterator();
		
		while(ite.hasNext())
		{
			System.out.println("Iterator : "+ite.next());
		}
		

	}

}
