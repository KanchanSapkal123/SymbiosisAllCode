package com.Collection;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

class Student9 {
	private int id;
	private String name;

	private int sub1;
	private int sub2;
	private int sub3;

	public Student9() {

	}

	Student9(int id, String name, int sub1, int sub2, int sub3) {
		this.id = id;
		this.name = name;
		this.sub1 = sub1;
		this.sub2 = sub2;
		this.sub3 = sub3;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSub1() {
		return sub1;
	}

	public void setSub1(int sub1) {
		this.sub1 = sub1;
	}

	public int getSub2() {
		return sub2;
	}

	public void setSub2(int sub2) {
		this.sub2 = sub2;
	}

	public int getSub3() {
		return sub3;
	}

	public void setSub3(int sub3) {
		this.sub3 = sub3;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", sub1=" + sub1 + ", sub2=" + sub2 + ", sub3=" + sub3 + "]";
	}

	public int getSub11()
	{
		
	
		return 0;
	}

}

public class TestStudentLinkedList {

	public static void main(String[] args) {

//		Student s1 = new Student();
		List<Student9> stulist = new LinkedList<Student9>();

		stulist.add(new Student9(101, "kanchan", 70, 50, 60));
		stulist.add(new Student9(102, "kalyani", 20, 50, 90));

		ListIterator<Student9> itr = stulist.listIterator();

		System.out.println("Student id: \t"+"Student Name: \t"+"Student marks Average: \t");
		while (itr.hasNext()) {
			Student9 s = itr.next();
			int Totalmarks = s.getSub1() + s.getSub2() + s.getSub3();
			int avg = Totalmarks / 3;
			System.out.println(s.getId()+"\t\t\t\t "+s.getName()+"\t\t"+ avg);
		}
	}
}
