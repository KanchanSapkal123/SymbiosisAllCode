package com;

import java.util.Scanner;

class Employee
{
	int code;
	double salary;
	
	Scanner sc=new Scanner(System.in);
	
	void input()
	{
		System.out.println("Enter employee code : ");
		code=sc.nextInt();
		
		System.out.println("Enter employee salary : ");
		salary=sc.nextInt();
		
	}
	
	void display()
	{
		System.out.println("employee code : "+code);

		System.out.println("employee salary : "+salary);

		
		
	}
}
public class EmployeeIdSallary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e=new Employee();
		e.input();
		e.display();
	}

}
