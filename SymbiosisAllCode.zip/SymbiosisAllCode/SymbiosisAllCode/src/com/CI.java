
package com;
import java.util.Scanner;

public class CI {

   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);

      double principal;
      double rate;
      double time;

      double compoundInterest;
  
      
      System.out.print("Enter the Principal amount : "); 
      principal = input.nextDouble();

      System.out.print("Enter the Rate : "); 
      rate = input.nextDouble();

      System.out.print("Enter the Time : "); 
      time = input.nextDouble();

      
      
      compoundInterest = principal * Math.pow((1 + rate/100),time); 
  
      System.out.println("");
      System.out.println("The Compound Interest is : " + compoundInterest);
  
   }

}