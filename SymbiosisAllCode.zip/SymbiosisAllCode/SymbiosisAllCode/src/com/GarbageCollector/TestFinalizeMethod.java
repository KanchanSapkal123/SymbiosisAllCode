package com.GarbageCollector;

public class TestFinalizeMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestFinalizeMethod t=new TestFinalizeMethod();
		
		System.out.println(t.hashCode());
		
		t=null;
		
		
		System.out.println("End of garbage collector : ");
		System.gc();
		
	}
	
	
	protected void finalize()
	{
		System.out.println("Inside finalize method : ");
	}
}
