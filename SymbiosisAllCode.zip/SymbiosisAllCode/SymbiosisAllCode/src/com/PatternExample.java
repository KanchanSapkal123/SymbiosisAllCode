package com;

class pattern23
{
	void display()
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println();

		}

	}	}


/*
 * 
 * 
 * output
 *  

1 
2 2 
3 3 3 
4 4 4 4 
5 5 5 5 5 


 */





public class PatternExample {

	public void main(String[] args) {
		// TODO Auto-generated method stub
		
		pattern23 t=new pattern23();
		t.display();
		
		
		
		
	}
}


