package com.map;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class TestTreeMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap<Integer,String> list=new TreeMap<Integer,String>();
		
		list.put(101,"Ajay");
		list.put(102,"Vijay");
		list.put(103,"Amit");
		list.put(104,"Sumit");
		
		
		for(Entry<Integer, String>  m : list.entrySet())
		{
			
			System.out.print(m.getKey()+" ");
			System.out.print(m.getValue()+" ");

		}
		System.out.println("*******************************************************************************");
		System.out.println("By using Iterator : ");
		
	     Iterator<Map.Entry<Integer,String>> iterator=list.entrySet().iterator();
	     
	     while (iterator.hasNext()) 
	     {
	    	 
	 	Map.Entry<Integer, String> m = iterator.next();

		System.out.println(m.getKey());
		System.out.println(m.getValue());

		
	     }
		
	}

}
