package com.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class TestLinkedHashMapEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedHashMap<Integer,String> list = new  LinkedHashMap<Integer,String>();

		list.put(102, "Ajay");
		list.put(102, "Vijay");
		list.put(102, "Sumit");
		list.put(102, "Amit");
		
		
		for (Map.Entry<Integer, String> m : list.entrySet()) 
		{
			System.out.println(m.getKey() + " : ");
			System.out.println(m.getValue());
		}

		for (Integer key : list.keySet()) 
		   {
			System.out.println("Keys set : " + key);

		}

		for (Integer val : list.keySet()) {
			System.out.println("valu e set : " + val);
		} 

	System.out.println("Using iterator : ");
	
	Iterator<Map.Entry<Integer, String>> iterator = list.entrySet().iterator();
	
		while (iterator.hasNext()) 
		{  
			
			Map.Entry<Integer, String> m = iterator.next();
			
		    System.out.println(m.getKey());
			System.out.println(m.getValue());
			
			
		}

	
		
		
		
		
		
		
		
		
		
	}

}
