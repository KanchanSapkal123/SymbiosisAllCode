package com.map;

import java.util.HashMap;
import java.util.*;

public class TestMap {

	public static void main(String[] args) {

		Map<Integer, String> map = new HashMap<Integer, String>();

		map.put(1, "Ajay");
		map.put(2, "Vijay");
		map.put(3, "Sanjay");
		map.put(4, "Jay");

		System.out.println(map);

		for (Map.Entry<Integer, String> m : map.entrySet()) {
			System.out.println(m.getKey() + " : ");
			System.out.println(m.getValue());
		}

		for (Integer key : map.keySet()) {
			System.out.println("Keys set : " + key);

		}

		for (Integer val : map.keySet()) {
			System.out.println("value set : " + val);
		}

		System.out.println("Using iterator : ");
		Iterator<Map.Entry<Integer, String>> iterator = map.entrySet().iterator();

		while (iterator.hasNext()) {
			Map.Entry<Integer, String> m = iterator.next();

			System.out.println(m.getKey());
			System.out.println(m.getValue());

		}

		// lambda for each loop
		map.forEach((k, v) -> System.out.println(k + "   " + v));

		System.out.println("\n");

		System.out.println(map.isEmpty());

		System.out.println(map.containsKey(2));

		if (map.containsKey(2)) {
			System.out.println("Key present : ");
		}
		System.out.println(map.containsValue("Ajay"));

		System.out.println(map.get(2));

		System.out.println(map.remove(2));

		System.out.println(map);
		System.out.println("********************************************************s");
		Map<Integer, String> map1 = new HashMap<Integer, String>();
		map1.putAll(map);
		System.out.println(map1);

		map1.clear();
		System.out.println(map1);
	}

}
