package com.map;

import java.util.*;

public class TestMapEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer,Employee>  hashMap=new HashMap<Integer,Employee>();
		
		Employee e1=new Employee(101,"Ajay");
		Employee e2=new Employee(102,"Vijay");
		
		
		
		hashMap.put(e1.getId(),e1);
		
		hashMap.put(e2.getId(),e2);
		
		for(Map.Entry<Integer, Employee> e:hashMap.entrySet())
		{
			System.out.println(e.getKey());
			Employee emp=e.getValue();
			System.out.println(emp);
		}
		
		
		Iterator<Map.Entry<Integer,Employee>> iterator=hashMap.entrySet().iterator();
		
		
		
		
		
		
	}

}
