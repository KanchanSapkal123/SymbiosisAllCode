package com.TreeSet;

class BookTheaterSeat
{
	
	int Total_Seat =30;
	void BookSeat(int seats)
	{
		
		if(Total_Seat>=seats) 
		{
			System.out.println("Seats can bookad");
		    Total_Seat = Total_Seat-seats;
		    System.out.println("remaining seats: "+Total_Seat);
		}else
		{
			System.out.println(" you are not able to book Seats");
		    //Total_Seat = Total_Seat-seats;
		   // System.out.println("remaining seats: "+Total_Seat);
			System.out.println("Remaining Seats : "+Total_Seat);
		}
		
	}
}
	class MyThread extends Thread
	{
		BookTheaterSeat b1;
		int seats;
		MyThread(BookTheaterSeat b1,int seats)
		{
			this.b1=b1;
			this.seats=seats;
		}
		
		@Override
		
		public void run()
		{
			b1.BookSeat(seats);
		}
		
     }






public class MovieBookApp {

	public static void main(String[] args) {
		
		BookTheaterSeat b1 = new BookTheaterSeat();
		MyThread t=new MyThread(b1,7 );
       t.start();

       MyThread t2=new MyThread(b1,6 );
       t2.start();



	}

}
