package com.TreeSet;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.*;

public class TestTreeSet {

	public static void main(String[] args)
	{
		
		//Why Treeset doese not allowe null value...?
		//Resen Tree set by default natural ordering..
		//we are use null value this are throw null value....
		//this are print assending value
		
		
		/*
		Set<String> sett=new TreeSet<String>();

		sett.add("delhi");
		sett.add("dubai");
		sett.add("mumbai");
		sett.add("pune");
		sett.add("Amaravati");
		
		
		
		System.out.println("Elements are : "+sett);
		System.out.println("**********************************************");
		Iterator iterator=sett.iterator();
		while(iterator.hasNext())
		{
			System.out.println(" print assending order Iterator ="+iterator.next());
		}
		
		System.out.println("**************************************************");
		//System.out.println("Print desending order ="+((Object) sett).desendingSet())
*/
		
		
		Set<Object> sett=new TreeSet<Object>();

		sett.add("delhi");
		sett.add("dubai");
		sett.add("mumbai");
		sett.add("pune");
		sett.add("Amaravati");
		
		
		
		System.out.println("Elements are : "+sett);
		System.out.println("**********************************************");
		Iterator iterator=sett.iterator();
		while(iterator.hasNext())
		{
			System.out.println(" print assending order Iterator ="+iterator.next());
		}
		
		System.out.println("**************************************************");
		//System.out.println("Print desending order ="+((Object) sett).desendingSet())
		//how is print assending order
		

	}

}
