package com;

public class TestChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch1 = 'a';  
		int ch2 = 'b';  
		System.out.println("The ASCII value of a is: "+ch1);  
		System.out.println("The ASCII value of b is: "+ch2);  
		
		
		
		}

}
