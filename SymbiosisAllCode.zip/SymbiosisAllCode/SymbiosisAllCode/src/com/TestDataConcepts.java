package com;

public class TestDataConcepts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int num1 = 5, sum = 0;
       sum+=num1;    //sum
		
		
	}

}
