package com;

import java.util.Scanner;

class Areacicle{
	 
	 int area,length ;
	
	 int width;
	
	Scanner sc=new Scanner(System.in);
	void input()
	{
		 System.out.println("Enter the area value : ");
		width =sc.nextInt();
			
		 System.out.println("Enter the width value : ");
			length =sc.nextInt();
			
	}
	
	void findarea() 
	{
		
		double area = length*width;
		System.out.println("Area of Circle : "+area);
	}
}


public class RectangleArea {

	public static void main(String[] args)
	{
		Areacicle a=new Areacicle();
		a.input();
		a.findarea();
	}

}
