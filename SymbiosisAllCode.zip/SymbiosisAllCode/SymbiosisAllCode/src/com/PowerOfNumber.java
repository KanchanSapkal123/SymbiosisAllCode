package com;

public class PowerOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String first= "101";
		String second="101";
		int num1 = Integer.parseInt(first,2);
		int num2 = Integer.parseInt(second,2);
		
		int sum=num1 + num2;
		
		System.out.println("num1 =" +num1+ "\n"+
				        "num2 ="+num2+ "\n"+
				        "result =" +sum+"\n"+
			"Binary "	+Integer.toBinaryString(sum));
		
		
	}
}