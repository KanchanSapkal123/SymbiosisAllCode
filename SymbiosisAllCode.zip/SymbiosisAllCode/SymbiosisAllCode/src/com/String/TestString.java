package com.String;

public class TestString {

	public static void main(String[] args) {
	
		
		String s1 ="welcome";                                            //Literal
        String s2=new String("Welcome");                                  //using New Keyword
        char ch[]= {'w','e','l','c','o','m','e'};                          //char Array
        
        String s3=new String(s1);
        String s4="welcome";
        
        
        System.out.println(s1.equals(s2));                                    //true
        System.out.println(s1.equals(s3));                                      //true
        System.out.println(s2.equals(s3));                                       //true
        
        System.out.println("************************************************");
        
        
        System.out.println(s1==s2);                                                
        System.out.println(s1==s3);
        System.out.println(s2==s3);
        System.out.println(s1==s4);
        
        System.out.println("************************************************");
        
        String s="Sachin";
        s.concat("Tendulakar");
        System.out.println(s);
        s=s.concat("Tendulkar");
        System.out.println("concatination Using Reasign "+s);
        
        System.out.println("**************************************************");
        
//        for(int i=0;i<=s.length();i++) {
//        	System.out.println();
//        }
        
        System.out.println("Comparison of Two String :");
        
        String one="Welcome";
        String two="Hello";
        String third="WELCOME";
        String four="Hello";
        
        System.out.println(one.compareTo(two));
        System.out.println((int)'W');
        System.out.println((int)'H');
        System.out.println(two.compareTo(third));
        System.out.println(two.compareTo(third));
        System.out.println(two.compareTo(four));
        
        
        System.out.println("*********************************************************");
        
        
        System.out.println("**********************Substring***************************");
        System.out.println(two.substring(1,3));
        
        
        s="Hello";
        s1="welcome";
        s2="JAVA";
        System.out.println(s.toUpperCase());
        System.out.println(s2.toLowerCase());
        System.out.println(s1.toUpperCase());
        
        
        System.out.println("*************************************************************");
        System.out.println("*************************Start with ends with****************");
        System.out.println(s.startsWith("H"));
        System.out.println(s.startsWith("h"));
        System.out.println(s.endsWith("o"));
        System.out.println(s.endsWith("O"));
        
        System.out.println("***********************************trim********************************");
        s=" Hello";
        System.out.println(s);
        System.out.println(s.trim());  
     //remove the space present frant and at the end of Sentence(" Hello") ---->o/p:-"Hello";

        
        System.out.println("************************************************************");
        
        
        System.out.println("*********************Char find index possition***************************");
        s="hello";
        System.out.println(s.charAt(2));
        
        
        System.out.println("********************************************************************");
        s=new String("hello");
        s1=s.intern();
        System.out.println(s1==s);
        
        
        System.out.println("***********************************************************************");
        
        int a=10;
        String str=new String.valueOf(a);
        System.out.println(str+10);
        System.out.println(a+10);
        
        System.out.println("******************************************************************");
        
        s1="This is java class";
        System.out.println(s1);
        s=s1.replace("java", "python");
        System.out.println(s);  
        System.out.println(s);
        
        System.out.println("*****************************************************************");
        
        System.out.println("IndexOf : ");
        String h="Hello World";
        System.out.println(h.indexOf('W'));
        System.out.println(h.indexOf('o'));
        System.out.println(h.indexOf('o',5));
        String sub="||";
        System.out.println(h.indexOf(sub));
        
	}

}

