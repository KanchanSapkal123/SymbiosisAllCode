package com.String;


public class StringAllExample {

	public static void main(String[] args) {
	
		
System.out.println("------------------   1 charAt(0)  Define Index Possition --------------------------");	
		

		String s1="hello";
		System.out.println(s1.charAt(0));
		
 System.out.println("-----------------    equals	check equality two string  -----------------------------");
		
		String s2="hello";
		String s3="HELLO";
		
		System.out.println(s2.equals(s3));
	
System.out.println("---------------------  concat() --------------------------------------------------------");
		

        String s4=("World");
        
        
        s4.concat("world");
        System.out.println(s4);                               //immutable String 
		
        
		//solution                                            
        s4=s4.concat("world");                                     //concat
        System.out.println(s4);
        
        
 System.out.println("-------------------equalsIgnoreCase() equal ignore karto-----------------------------------------------");    
 
 
    String s6="hello";
	String s9="HELLO";
	
	
	System.out.println(s6.equalsIgnoreCase(s9));

        
	System.out.println("------------IndexOf() define position  --------------------------------------------------------");
	
	
	String s10="hello";
	System.out.println(s10.indexOf('e'));
	
	System.out.println("-------------------------- length() define Srting length------------------------- ");
	
	String s11="hello";
	System.out.println(s11.length());
	
	System.out.println("------------substring() Provide a limite Substring is show the output ------------------------------");
	
	String s12="good morning";
	System.out.println(s12.substring(4));
	System.out.println(s12.substring(4,9));
	
	System.out.println("--------------------------------------------------------------trim krne mean word la trim karto--------------------------------------------------------------------");
	
	String s13="Hello";
	System.out.println(s13.trim());
	
	
	System.out.println("--------------------------------------------------------toLowerCase----------------------------------------");
	String s14="HELLO";
	
	s14.toLowerCase();
	System.out.println(s14);
	
	System.out.println("---------------------------------------------toUpperCase()----------------------");
	
     String s15=" hello";
	s14.toUpperCase();
	System.out.println(s15);
	}
}