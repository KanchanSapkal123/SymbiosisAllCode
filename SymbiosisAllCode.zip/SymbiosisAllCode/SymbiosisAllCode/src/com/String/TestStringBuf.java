package com.String;

public class TestStringBuf {

	public static void main(String[] args) {
	
		StringBuffer sb=new StringBuffer("hello");
		sb.append("world");
		System.out.println("*1..***************************       append is used to joining ***");
		
		System.out.println("append : \n "+sb);
		
		System.out.println("*2..********************************   insert  add new element ***");
		sb.insert(5, "java");
		System.out.println("Insert at Index : \n"+sb);
		
		
		
		
		System.out.println("*3..******************************   reverse is used to reverse the word  ***");
		sb.reverse();
		System.out.println("Reverse : \n "+sb);
		
		
		System.out.println("*4..**************************  find the possition  ***");
		StringBuffer s=new StringBuffer("This is Java class");
		System.out.println(s.indexOf("java"));
		
		System.out.println("5..*****************************   replace word ***");
          s.replace(8, 12, "Pythan");
          System.out.println("replace :"+s);
          
          System.out.println("*6..****************************");
          StringBuffer sb2=new StringBuffer();
          
          
          
          System.out.println(sb2.capacity());
          
          sb2.append("Hello"); 
          
          
          
          sb2.append("Welcome To Java Programming : ");
          
          System.out.println("Capacity when long String  : "+sb2.capacity());
          
          sb2.ensureCapacity(10);
          
          System.out.println("Ensure Capacity : "+sb2.capacity());
          //if it is sufficient then it will not chang an if it is greter so 
          //its not sufficience for it then will increase its capasity
          
          System.out.println("Ensure capacity : "+sb2 .capacity());
          
          sb2.append("Java Programming");
          
          System.out.println(sb2);
          
          sb2.delete(0,5);
          
          System.out.println();
          StringBuilder sb1=new StringBuilder("java");
          
          sb2.append("languages");
          
          System.out.println("**************************************************************");
          
          String st="This is java class";
          
          
          String arr[]=st.split("");
          st.split("");
          for(String sp : arr) 
          {
          System.out.println(arr);
          }
          
          
          
          
          
          
          
		

	}

}
