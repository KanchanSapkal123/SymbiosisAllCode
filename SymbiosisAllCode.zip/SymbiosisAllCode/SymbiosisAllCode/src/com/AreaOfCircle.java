package com;

import java.util.Scanner;

class TringleArea{
	
	 int length,width ;
	
	Scanner sc=new Scanner(System.in);
	void input()
	{
		 System.out.println("Enter the length value : ");
			width =sc.nextInt();
			
		 System.out.println("Enter the width value : ");
			length =sc.nextInt();
			
	}

	void findarea() 
	{
		double area = length*width/2;
		System.out.println("Area of tringle : "+area);
}
}


class CicleArea{
	 
	 int radius ;
	
	
	Scanner sc=new Scanner(System.in);
	void input()
	{
		
		 System.out.println("Enter the radius value : ");
			radius =sc.nextInt();
			
 	}
	
	void findarea() 
	{
		
		double area = Math.PI*radius*radius;
		System.out.println("Area of Circle : "+area);
	
	}
}

public class AreaOfCircle {

	public static void main(String[] args) 
	{

		CicleArea c=new CicleArea(); 


		c.input();
		c.findarea();
		System.out.println(c);
		
		TringleArea t=new TringleArea();
		
		t.input();
		t.findarea();
		System.out.println(t);

		
	}
}