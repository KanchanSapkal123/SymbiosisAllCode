package com;

import java.util.Scanner;

class TestCharValue
{
	
	int Ch1='a';
	int Ch2='b';
	//Scanner sc=new Scanner(System.in);
	
    void input() {
//	
//	System.out.println("Enter your charactet 1 : ");
//			
//	         Ch1=sc.nextInt();
//			
//	System.out.println("Enter your charactet 2 : ");
//
//			 Ch2=sc.nextInt();
	
	}
	
	void checkCondition()
	{
		
		System.out.println("Ascii value Char1 is : "+Ch1);
		System.out.println("Ascii value Char2 is : "+Ch2);
		
		
	}
}

public class TestCharInt {

	public static void main(String[] args) {
		TestCharValue  t=new   TestCharValue();
		           t.input();
		           t.checkCondition();

	}

}
