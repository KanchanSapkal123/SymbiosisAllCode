package com;

import java.util.Scanner;

class TestNumber
{
	public void TestNumber()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		
		int n=sc.nextInt();
		int m=n,s=0;
		
  for(int i=1;i<n;i++)
	  
	  	  
	  
	}
}
	
public class FactorialNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
''


