package com;

public abstract class Testpattern1234 {

	
	void display()
	{
		
		
		
	}
	
	public static void main(String[] args) {

		

		
		
		 
		
	}

}
