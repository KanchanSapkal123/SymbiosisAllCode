package com.Serializable;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class TestDeserialization {

	public static void main(String[] args) 
	{TestStudentInfo s=null;
		try 
		{
			//TestStudentInfo s=null;
			FileInputStream fln=new FileInputStream("New DOC Document");
			
			ObjectInputStream oln=new ObjectInputStream(fln);
			
			s=(TestStudentInfo) oln.readObject();
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		System.out.println(s.name);
		
		System.out.println(s.id);
	}

}
