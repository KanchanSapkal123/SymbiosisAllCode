package com.Serializable;

public class TestStudentInfo {

	int id;
	static String name;
	static String contact;
	
	TestStudentInfo(String n ,int r,String c)
	{
		
		this.name=n;
		this.id=id;
		this.contact=c;
	}

}
