package com.Serializable;

import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class TestSerializable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try 
		{
			TestStudentInfo t=new TestStudentInfo("Kalyani",104,"8767529588");
			
			
			FileOutputStream s=new FileOutputStream("New DOC Document");
			
			ObjectOutputStream o=new ObjectOutputStream(s);
			
			o.writeObject(t);
			o.close();
			//t.close();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
		System.out.println();
		
		
		
		
	}

}
