package com;

import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
					
		System.out.println("Enter the value of principle : ");
		float principle= sc.nextFloat();
		
		System.out.println("Enter the value of rate : ");
		int rate=sc.nextInt();
		
		System.out.println("Enter the value of time : ");
		int time=sc.nextInt();
			
	    double simpleInrest;
	    
	    simpleInrest=(principle*rate*time)/100;
	    
		System.out.println("principle : " +principle+ "\n"+ "rate : "+rate+ "\n"+ "time : " +time);
		
		
		System.out.println("Simple interest is : " +simpleInrest);
		

	}

}
