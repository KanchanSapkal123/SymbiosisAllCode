package com;

import java.util.Scanner;

class Age {
	Scanner sc=new Scanner(System.in);
	
	void validAge(int age)
	{
		System.out.println("Enter your age : ");
		
		age=sc.nextInt();
		if(age>=18)
		{
			System.out.println("Age is greter than 18 : ");
		}
		else
		{ 
			System.out.println("Age is less than 18 : ");
		}
		
	}
	
}

public class AgeIsGreterOrNot {

	public static void main(String[] args) {
		
		Age a=new Age();
		a.validAge(21);
		
		
		
		
//		int age;
//
//		Scanner sc=new Scanner(System.in);
//		age=sc.nextInt();
//		
//		
//		if(age>=18)
//		{
//			System.out.println("Age is greter 18 : ");
//		}
//		else
//		{
//			System.out.println("Age is not greter 18 : ");
//		}
		
// by using method
	}

}
