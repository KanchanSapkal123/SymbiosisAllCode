package com.Array7_3_2023;

import java.util.Scanner;

import DoWhile_break_continue.For_break;

class Multiplication
{
	int row,col,rowSum,colSum;
	
	Scanner sc=new Scanner(System.in);
	int arr[][]=new int[2][2];
	int arr2[][]=new int[2][2];
	int[][] mul=new int[2][2];
	
	void input()
	{
		System.out.println("Enter row number : ");
		row=sc.nextInt();
		
		System.out.println("Enter col number : ");
	    col=sc.nextInt();
	    
	    for (int i = 0; i < arr.length; i++) 
	    {
			for (int j = 0; j < arr.length; j++) 
			{
				arr[i][j]=sc.nextInt();
			}
		}
	    
	    System.out.println("Enter second array : ");
	    
	    for (int i = 0; i < arr.length; i++) 
	    {
			for (int j = 0; j < arr.length; j++) 
			{
				arr2[i][j]=sc.nextInt();
			}
		}
	}
	
	void display()
	{
		System.out.println("display number : ");
		for (int i = 0; i < arr.length; i++) 
		{
			for (int j = 0; j < arr.length; j++) 
			{
				System.out.println(arr[i][j]);
			}
		}
		
		System.out.println("display second Array : ");
		for (int i = 0; i < arr2.length; i++) 
		{
			for (int j = 0; j < arr2.length; j++) 
			{
				System.out.println(arr2[i][j]);
			}
		}
	}
	
	void check()
	{
		for (int i = 0; i < arr.length; i++) 
		{
			for (int j = 0; j < arr.length; j++)
			{
				mul[i][j]=arr[i][j]+arr2[i][j]*arr[i][j];
			}
		}
	}
	
void displayMatrix() 
{
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			System.out.println(arr[i][j]+" "+arr2[i][j]+"  "+mul[i][j]);
		}
		System.out.println( );
	}
}

}


public class TestMultiplicationOfTwoMatrix {

	public static void main(String[] args) {

		Multiplication m=new Multiplication();
		m.input();
		m.display();
		m.check();
		m.displayMatrix();

		
		
		
	}

}
