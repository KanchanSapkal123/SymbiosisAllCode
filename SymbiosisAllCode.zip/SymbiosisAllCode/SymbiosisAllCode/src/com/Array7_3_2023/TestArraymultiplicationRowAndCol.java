package com.Array7_3_2023;

import java.util.Scanner;

class MulArray
{
	int row ,col;
	int mulRows,mulCols;
	
int	mulCol[][]=new int[2][2];
int mulRow[][]=new int[2][2];

	Scanner sc=new Scanner(System.in);
	int [][]  input()
	{
		System.out.println("Enter row element if you want : ");
		row=sc.nextInt();
		
		System.out.println("Enter col element if you want :  ");
		col=sc.nextInt();
		
		
		int arr[][]=new int[row][col];
	
		System.out.println("Enter Array Element : ");
		
		for (int i = 0; i < arr.length; i++) 
		{
			for (int j = 0; j < arr.length; j++) 
			{
				arr[i][j]=sc.nextInt();
			}
			System.out.println(   );
		}
		return arr;
		
	}
	
	void display(int arr[][]) 
	{

		for (int i = 0; i < arr.length; i++) 
		{
			for (int j = 0; j < arr.length; j++) 
			{
			System.out.println(arr[i][j]);
			}
			System.out.println(   );
		}

	}
	
	
	void check(int arr[][])
	{

		System.out.println("Row Multiplication : ");
		for (int i = 0; i < row; i++) 
		{
			mulRows=1;
			for (int j = 0; j < col; j++) 
			{
                     mulRow[i][j]=mulRows*arr[i][j];
			}
		}
//System.out.println(" "+mulRow);
		
		
		
		System.out.println("call multiplication : ");
		for (int i = 0; i < col; i++) 
		{
			mulCols=1;
			for (int j = 0; j < row; j++) 
			{
				mulCol[i][i]=mulCols*arr[i][j];
			}
		}
		//System.out.println(" "+mulCol);
		
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = 0; j < arr.length; j++)
			{
				System.out.print(mulRow[i][i]+" ");
				System.out.print(mulCol[i][j]);
			}
			System.out.println(  );
		}
	}
}

public class TestArraymultiplicationRowAndCol {

	public static void main(String[] args) {
	
		
		MulArray m=new MulArray();
		
	int a[][] =m.input();
    int b[][]=m.input();
		
    
		m.display(a);
		m.check(a);
	}

}
