package com.Array7_3_2023;

import java.util.Scanner;

class Array
{
	int rowSum,colSum;

	Scanner sc=new Scanner(System.in);
	
	int arr[][]=new int[3][3];
	
	int row=arr.length;
     int col=arr[0].length;
     
	void input() 
	{
		System.out.println("Inter row number : ");
		row=sc.nextInt();
		
		System.out.println("Inter coll number : ");
		col=sc.nextInt();
		
		System.out.println("Enter Array number : ");
		
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = 0; j < arr.length; j++)
			{
				arr[i][j]=sc.nextInt();
			}
			System.out.println( );
		}
	
		}
	
	void display()
	{
		System.out.println("Display number : ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println( );
		}
		
	}
	
	void check()
	{
		
		System.out.println("sum of row : ");
		for (int i = 0; i < row; i++)
		{
		rowSum = 0;
			
			for (int j = 0; j < col; j++)
			{
				rowSum=rowSum + arr[i][j];
				
			}
			System.out.println( );
		}
		System.out.println( " "+rowSum);

		
		
		
		
System.out.println("Sum of collumn");
	for (int i = 0; i < col; i++)
	{
	colSum = 0;
		
		for (int j = 0; j < row; j++)
		{
			colSum=colSum + arr[i][j]+arr[i][j];
			
		}
		System.out.println( );
	}
	System.out.println(" "+colSum);
	
	

}

}

public class TestArraySumOfRowAndCollam {

	public static void main(String[] args) {
		
		Array a=new Array();
		
		a.input();
		a.display();
		a.check();

	}

}
