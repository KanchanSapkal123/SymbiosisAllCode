package com.Array7_3_2023;

import java.util.Scanner;

class Matrix
{
	
	
	Scanner sc=new Scanner(System.in);
	int arr[][]=new int[3][3];
	
	
	void input()
	{
		
		System.out.println("Enter the number : ");
		
		
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = 0; j < arr.length; j++)
			{
				arr[i][j]=sc.nextInt();
			}
			System.out.println( );
		}
	}
	

	void display() 
	{
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = 0; j < arr.length; j++)
			{
				System.out.print(arr[i][j]);
			}
			System.out.println( );
		}
	}
	
	
	void check()
	{
		System.out.println("This is  matrix : ");
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = 0; j < arr.length; j++)
			{
				if(i>j) {
					System.out.print("0 ");
				}
			else 
			{
				System.out.print(arr[i][j]+" ");
				}
				
			}
			System.out.println( );
		}
	}
}


public class TestLowerrMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Matrix m=new Matrix();
		m.input();
		m.display();
		m.check();
		
	}

}
