package com;

public class RecursionFactorial {

	static int factorial(int n)
	{
		int fact = 1,power=2;
		for(int i=0;i<=power;i++) {
			fact=fact*n;
			System.out.println(+fact);
		}
		return fact;
		

	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		factorial(5);
	}

}
