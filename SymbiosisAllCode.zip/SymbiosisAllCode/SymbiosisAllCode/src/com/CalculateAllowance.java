package com;

import java.util.Scanner;

class EmployeeAllowance
{
	int allowance;
	double Salary;
	
	
	Scanner sc=new Scanner(System.in);
	
	void input() 
	{
		System.out.println("Enter Employee Allowance : ");
		allowance=sc.nextInt();
		
		System.out.println("Enter Employee salary : ");
		Salary=sc.nextInt();
	}
	
	void display(){
	double	salary=Salary+allowance;
	
	System.out.println("Employee total salary : "+salary);
	}
	
}

public class CalculateAllowance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeAllowance e=new EmployeeAllowance();
		e.input();
		e.display();
	}

}
