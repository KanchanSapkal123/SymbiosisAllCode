package com;

import java.util.Scanner;

public class FahrenheitCelsius {

	public static void main(String[] args) {
    // TODO Auto-generated method stub
				
 Scanner sc=new Scanner(System.in);
		
 System.out.println("Enter Value fahrenheit");
 float fahrenheit=sc.nextFloat();

	/*
	 * System.out.println(" vf vf vf vEnter Value celsius"); float celsius=sc.nextFloat(); 
	 */
	float celsius;	
		
		celsius = ((fahrenheit-32)*5/9);
		
		System.out.println("Temperature in celsius is  : "+celsius);
		
		
	}
}
