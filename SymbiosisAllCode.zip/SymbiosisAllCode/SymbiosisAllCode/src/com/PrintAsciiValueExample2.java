package com;

public class PrintAsciiValueExample2 {

	public static void main(String[] args) {
     char ch1='a';
     char ch2='b';
     
     System.out.println("The ASCII value of a is : "+ch1);
     System.out.println("The ASCII value of b is : "+ch2);
    
     
	}
}
