package com;

public class unaryoperator {

	public static void main(String[] args) {
		// pre increament operator      pehale increment karo fir assign kro
		//post increament operator      pehale  assign kro fir increment kro

		System.out.println();
		System.out.println();
		
		
		   
		
		
	}

}
