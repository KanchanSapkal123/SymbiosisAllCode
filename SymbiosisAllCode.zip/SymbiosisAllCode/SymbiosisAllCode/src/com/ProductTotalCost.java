package com;

import java.util.Scanner;

class TotalCost
{
	int price,quantity;
	
	Scanner sc=new Scanner(System.in);
	
	void input()
	{
		System.out.println("Enter Product price : ");
		price=sc.nextInt();
		
		System.out.println("Enter product Quantity ");
		quantity=sc.nextInt();
	}
	
	void display()
	{
		int total= price*quantity;
		System.out.println("total is ="+total);
		
		int discount= (int) (total*0.1f);//farmula discount
    	float NetAmount=total - discount;    
    		
		System.out.println("output : "+NetAmount);
				
		//just simple concatination
				
		System.out.println("the price of product is : "+price);
		System.out.println("the quantity of product is : "+quantity);
		System.out.println("the total of product is : "+total);
		System.out.println("the NetAmount be paid at per 10% discount applied : "+NetAmount);
	}
}

public class ProductTotalCost {

	public static void main(String[] args) {
	
		
		TotalCost t=new TotalCost();
		
		t.input();
		t.display();
		

	}

}
