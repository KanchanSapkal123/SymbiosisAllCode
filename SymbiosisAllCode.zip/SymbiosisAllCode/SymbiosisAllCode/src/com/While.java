package com;

public class While {

	public static void main(String[] args) {
	
		int product;
		product=1;
		int i =1;
		while(i<=5)
		{
			product*=i;             //
			i++;
			
		}
                
		System.out.println("product is "+product);
		
		
	}

}
