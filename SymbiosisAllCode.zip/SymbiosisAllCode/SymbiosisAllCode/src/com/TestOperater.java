package com;

import java.util.Scanner;

public class TestOperater {

	public static void main(String[] args) {

		//int num1 ,num2 , result;
		System.out.println("enter your value");
		Scanner sc= new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		int result;
		
		result=num1+num2;
		System.out.println("result"+result);
		
		result=num1*num2;
		System.out.println("result"+result);
		
		result=num1/num2;
		System.out.println("result"+result);
		
		result=num1-num2;
		System.out.println("result"+result);
		
		
		
	}

	

	

}
