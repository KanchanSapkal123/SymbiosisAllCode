package com;

import java.util.Scanner;

public class CompoundInterest {

	public static void main(String[] args) {
	
				

				Scanner sc=new Scanner(System.in);
				double principle;
				double rate;
				double time;
				
				double CompoundInterest;
				System.out.println("Enter principle amount : ");
				principle=sc.nextDouble();
				
				System.out.println("Enter rate : ");
				rate=sc.nextDouble();
				

				System.out.println("Enter time duration : ");
				time=sc.nextDouble();

				CompoundInterest=principle*Math.pow((1+ rate/100),time);
				
				System.out.println("The Compound interest is : "+CompoundInterest);
			}

		

				
				
				
				
	}


