package com;

import java.util.Scanner;

public class TestScanner {

	public static void main(String[] args) {
	
		
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your name");
		String name=sc.next();
		System.out.println("Enter your age ");
	     int age=sc.nextInt();
	     System.out.println("Enter your marks");
	     float Marks=sc.nextFloat();
	     System.out.println("Enter your fees");
	     double fees=sc.nextDouble();
	     System.out.println("Enter your gender");
	     char gender=sc.next().charAt(0);
	     System.out.println("name : " +name+"\n"+ "age : " +age+ "\n"+ "Marks : " +Marks+"\n"+ "fees : " +fees+"\n"+ "gender : "+gender);
	     
	}
	}