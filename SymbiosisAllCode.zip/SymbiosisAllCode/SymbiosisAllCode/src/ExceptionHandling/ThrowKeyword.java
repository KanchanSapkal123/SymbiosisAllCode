package ExceptionHandling;

import java.util.Scanner;

public class ThrowKeyword {

	public static void check(int num) 
	{
		if(num>0)
		{
			System.out.println("Number is positive");
		}
	   else {
				try
				{
				
				throw new ArithmeticException("Negative number Exception");	
				}
				catch(ArithmeticException e)
				{
					e.getMessage();
					System.out.println(e);
				}
		}		
	}
	
	
	static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		
		int n=sc.nextInt();
		
		check(n);
		System.out.println("Rest of the code");
		
		
		
	}

}
