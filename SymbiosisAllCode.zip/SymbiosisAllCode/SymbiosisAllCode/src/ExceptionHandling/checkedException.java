package ExceptionHandling;

import java.util.Scanner;

public class checkedException extends Exception {
	
	checkedException(String s){
		super(s);
	}
	
	static int age;
	
	static void checkExcp() {
	
	if(age>=18) 
	{
		System.out.println("valid for voting");
	}
	else 
	{
		//System.out.println("Not valid for voting");
		try {
			throw new checkedException("Not valid for voting3");
		}
		catch(checkedException e) {
			System.err.println(e);
		}
	}
	}
	
	public static void main(String[] args)
	{                           
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
          int n=sc.nextInt();
          checkExcp();
	}
}
