package ExceptionHandling;

import java.io.IOException;
import java.util.Scanner;

public class Uncheck {

		public static void check(int num) throws IOException
		{
			if(num>0)
			{
				System.out.println("Number is positive");
			}
		   else {
					try
					{
					
					throw new ArithmeticException("Negative number Exception");	
					}
					catch(ArithmeticException e)
					{
						e.getMessage();
						System.out.println(e);
					}
			}		
		}
		
		static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub

			Scanner sc=new Scanner(System.in);
			System.out.println("Enter a number");
			
			int n=sc.nextInt();
			try {
			check(n);
			System.out.println("Rest of the code");
			
		}catch(Exception e)
			{
			System.out.println(e);
			}
			 }
}
