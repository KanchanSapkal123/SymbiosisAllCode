package ExceptionHandling;

public class TryFinaly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try
		{
			int n=6/2;
			System.out.println(n);
		}
		finally
		{
			System.out.println("finally always excecuted");
		}
		System.out.println("Rest of the code");
		

	}

}
