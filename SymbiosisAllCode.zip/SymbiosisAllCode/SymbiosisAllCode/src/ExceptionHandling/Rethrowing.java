
//package ExceptionHandling;

import java.io.IOException;
import java.util.Scanner;

public class Rethrowing {

			public static void check(int num) throws IOException
			{
				if(num>0)
				{
					System.out.println("Number is positive");
				}
			   else {
						try
						{
						
						throw new ArithmeticException("Negative number Exception");	
						}
					/*	catch(ArithmeticException e)
						{
							//e.getMessage(); 
							//jvm massage deto ka baghital
							System.out.println(e);
                            
							throw e;

						}*/
						throw e;

			   
						//System.out.println(e);
					//	throw e;
						}
				}		
			
			
			
		public static void main(String[] args) throws IOException {
			

				Scanner sc=new Scanner(System.in);
				System.out.println("Enter a number");
				
				int n=sc.nextInt();
				try 
				{
				check(n);
				
				
			    }catch(Exception e)
				{
			    	
				System.out.println(e);
				
				}
				System.out.println("Rest of the code");

				 }

			}

	
	
	
	


		
		
		
		
		
	


