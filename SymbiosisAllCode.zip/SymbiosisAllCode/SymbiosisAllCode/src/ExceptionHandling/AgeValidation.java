package ExceptionHandling;

import java.util.Scanner;

public class AgeValidation extends RuntimeException{                          // custom uncheck Exception this is runtime exception

	public static void validation(int age) {
		if(age>=18)
		{
			System.out.println("valid for voting");
		}else {
			System.out.println("Not valid for voting");
			try {
				//throw new AgeValidation();
			}
			catch(AgeValidation e)
			{
				System.err.println(e);
			}
		}
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
          int n=sc.nextInt();
          validation(n);
	}
}