package ExceptionHandling;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class TestException2
{

public static void main(String[] args) {
	
try {
      try 
      {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
	System.out.println("Enter name");	
	String	name = br.readLine();
	System.out.println(name);
		
	System.out.println("Enter id");
	int id=Integer.parseInt(br.readLine());
	System.out.println(id);
    }
      catch(Exception e)
		{
			e.printStackTrace();
		}
}

catch(Exception e)
{
	e.printStackTrace();

	
}
	
		
	}

}