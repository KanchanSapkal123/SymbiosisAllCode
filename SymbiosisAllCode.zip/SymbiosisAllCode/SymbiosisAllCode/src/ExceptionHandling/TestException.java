package ExceptionHandling;

public class TestException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=5,b=0;
		int c= a+b;
		System.out.println(c);
		
		
		
		try {
		int d=a/b;
		
		System.out.println(d);
		
		}catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
		
		
		
		int e=a-b;
		
		System.out.println(e);

		int f=a+b;
		
		System.out.println(f);
		
		System.out.println("rest of program");
		
		
		
		
		
		

	}

}
