package Logic;

public class looplogic {
	
	
	void display() 
	{
		for(int i=5 ;i>=1 ;i--)                                                      //row reverse
		{
			for(int j=1;j<=i;j++)                                              // collam 
			{				
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
	
	
	/*
	
5 5 5 5 5 
4 4 4 4 
3 3 3 
2 2 
1 
*/	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		looplogic l=new looplogic();
		l.display();
		
		
		
		
	}

}
