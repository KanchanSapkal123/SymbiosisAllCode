package Logic;

public class logic_java {

	public static void main(String[] args) {
	
		System.out.println(+'j');
		System.out.println(+'a');
		System.out.println(+'v');
		System.out.println(+'a');

		
		
		
		
		System.out.println('j'+'a'+'v'+'a');

	}

}
