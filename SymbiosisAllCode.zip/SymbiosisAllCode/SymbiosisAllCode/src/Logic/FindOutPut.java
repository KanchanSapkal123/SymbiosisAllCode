package Logic;

import java.util.Scanner;

class Employee 
{
	private int id;
	private String name;
	
	
	Scanner sc=new Scanner(System.in);
    
	Employee()
	{
		
	}
	
//	Employee(int x)
//	{
//		id=x;
//		name=" ";
//	}
	
	Employee(int x,String s1)
	{
		this.id=x;
		this.name=s1;
	}
	
//	void input() 
//	{
//		
//	}
	
	void display() 
	{
		
		System.out.println("Enter id");
		int id=sc.nextInt();
		
		System.out.println("Enter name");
		String name=sc.next();
		
		System.out.println("Employee id="+id);
	    System.out.println("Employee name="+name);
			
	}
}
public class FindOutPut 
{                                                      
	public static void main(String[] args) 
	{
		Employee ob2=new Employee();

		ob2.display();
	}
	}