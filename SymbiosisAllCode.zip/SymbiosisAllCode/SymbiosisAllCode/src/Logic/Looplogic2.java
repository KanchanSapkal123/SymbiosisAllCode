package Logic;

public class Looplogic2 {

	void display()
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println();

		}

	}	
	/*
1 
2 2 
3 3 3 
4 4 4 4 
5 5 5 5 5 


	 */
	
	public static void main(String[] args)
	{
		Looplogic2 l=new Looplogic2();
		l.display();
		
	}

}
