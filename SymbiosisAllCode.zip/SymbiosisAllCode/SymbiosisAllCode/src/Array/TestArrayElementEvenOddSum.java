package Array;

import java.util.Scanner;

public class TestArrayElementEvenOddSum {

	public static void main(String[] args) {

		int sumE = 0, sumO = 0;

		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter element array  : ");
		
		int arr[]=new int[5];
		
		
				
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
			
		}
		
		
		System.out.println("-----------------------------Even number------------------------------------------------");
		for(int i=0;i<arr.length;i++)
		{
	            if(arr[i]%2==0)
	            {
	            System.out.println(arr[i]);
	            	
	            	sumE=sumE+arr[i];
	            }       
		}
		
		System.out.println("Even number sum "+sumE);

		
		
		
		
		System.out.println("-----------------------------Odd number ------------------------------------------------");

		for(int i=0;i<arr.length;i++)
		{
	            if(arr[i]%2!=0)
	            {
	            	System.out.println(arr[i]);
	            	
	            	sumO=sumO+arr[i];
	            }       
		}
		

		System.out.println("Odd number sum "+sumO);
		
	}

}
