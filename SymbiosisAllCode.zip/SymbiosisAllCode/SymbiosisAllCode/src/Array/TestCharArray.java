package Array;

public class TestCharArray {

	public static void main(String[] args) {
		char a[]= {'a','b','c','d','e','f','g'};
		
		for(int i=0;i<a.length;i++)

		System.out.println(a[i]);
		
		
	}

}
