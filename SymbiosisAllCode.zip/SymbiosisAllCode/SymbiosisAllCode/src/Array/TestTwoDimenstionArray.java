package Array;

import java.util.Scanner;

 class Twodi
{
	 int sum = 0;

	int [][] input() 
	{
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter how many row you want");
		int row=sc.nextInt();
		System.out.println("Enter how many collum you want");
		int col=sc.nextInt();
		
		
		int arr[][]=new int[row][col];
		int sum;
		
		System.out.println("Enter two dimenstion array");
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		return arr;
	}
		
		//System.out.println("display 2d arry");
		
	
	void show(int arr[][])
		{
			for(int i=0;i<arr.length;i++)
			{
				for(int j=0;j<arr[i].length;j++)
				{
					
					System.out.print(arr[i][j]+" ");
					
					
				}
				System.out.println(   );
			}
			

		}

	public int sum(int arr[][]) 
	{
	int sum=0;
	
	for(int i=0;i<arr.length;i++)
	{
		
		for(int j=0;j<arr[i].length;j++)
		{
			sum=sum + arr[i][j];
			
			//System.out.print(arr[i][j]+" ");
		}
		
				
		System.out.println( "sum =" +sum );
	}
	return sum;
}

	public int evenOdd(int arr[][]) 
	{
	int evenSum=0,oddSum=0;
	
	for(int i=0;i<arr.length;i++)
	{
		
		for(int j=0;j<arr[i].length;j++)
		{
			if(arr[i][j]%2==0)
				evenSum+=arr[i][j];
			else
				oddSum+=arr[i][j];
		}
		
		
				
		System.out.println("Even number =" +evenSum );
		System.out.println("Odd number =" +oddSum );
		
	}
	return sum;
}
	


	public void display(int arr[][])
	{
		for(int []i:arr) {
			for(int j:i){
				System.out.println(j);
			}
			System.out.println( );
		}
		
		
	}
		
}
 
public  class TestTwoDimenstionArray {

	public static void main(String[] args) {
	
		Twodi t=new Twodi();
	
		int arr[][]=t.input();
		
		t.show(arr);
		
		int sum=t.sum(arr);
		
		System.out.print("sum is =  "+sum);
		
		int evenOdd=t.evenOdd(arr);
		
		System.out.println("even odd"+evenOdd);
		
		t.display(arr);
		
		
	}
}
