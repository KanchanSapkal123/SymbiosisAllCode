package Array;

import java.util.Scanner;

public class TestArrayMaximumAndMinimumValue {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter element in an Array ");
		
		int arr[]=new int[10];
		
		
		int max=arr[0];
		int min=arr[0];
		
		for(int i=0;i<arr.length;i++)
		{
		 arr[i]=sc.nextInt();	
		 
		 if(arr[i]>max)
		 {
			 max=arr[i];
		 }
		 	 
		 else if(min>arr[i])
		 {
			 min=arr[i];
		 }
		 
		}
			
		System.out.println("maximum element="+max);
		System.out.println("mimimum element="+min);

		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}}}