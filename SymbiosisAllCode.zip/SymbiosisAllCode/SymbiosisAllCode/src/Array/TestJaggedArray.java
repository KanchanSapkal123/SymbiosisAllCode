package Array;

import java.util.Scanner;

public class TestJaggedArray {
    static int [][] input()
    {
    	Scanner Sc=new Scanner(System.in);
    	
		int arr[][]=new int[3][];
		
	    arr[0]=new int[2];        //define first row
		arr[1]=new int[3];        //define second row
		arr[2]=new int[1];           //define third row
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=Sc.nextInt();
			}
		}
		return arr;
    	
    }
    
   void  display(int arr[][])
    {
    	for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++)
			{
		
				
				System.out.print(arr[i][j]+" ");
			}
			System.out.println( );
		}
   

    }
    
	public static void main(String[] args) {
	
		TestJaggedArray t=new TestJaggedArray();
	
		int arr[][] =t.input();
	
		t.display(arr);
		
/*		Scanner Sc=new Scanner(System.in);
	
		int arr[][]=new int[3][];
		
		
	    arr[0]=new int[2];        //define first row
		arr[1]=new int[3];        //define second row
		arr[2]=new int[1];           //define third row
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=Sc.nextInt();
			}
		}

		
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++)
			{
		
				
				System.out.print(arr[i][j]+" ");
			}
			System.out.println( );
		}
		*/
		
	}

}
