package Array;
import java.util.Scanner;


class Student 
{
	int id;
	String name;
	
	Student(int id,String name)
	{
	
		this.id=id;
		this.name=name;
	}
	
//	void display()
//	{
//		System.out.println(" id="+id +"name="+name);
//	}
	
	public String toString()
	{
		return id+" "+name;
		
	}
}

public class TestArrayOfObject {

	public static void main(String[] args) {
	
	//	Student s=new Student(101,"Ajay");
		
		Student[] s=new Student[2];
	
		for(int i=0;i<s.length;i++) {
			
			System.out.println("Enter id");
			int id=new Scanner(System.in).nextInt();
			
			System.out.println("Enter name");
			String name=new Scanner(System.in).next();
			
			s[i]=new Student(id,name);
		
			}
		 
		for(int i=0;i<s.length;i++) {
			
			//s[i].display();
			
			System.out.println(s[i]);
		}
	}
}
