package Array;

import java.util.Scanner;

public class ArraySum {
	
int sum;
int arr[]=new int[0];

int arr1[]=new int[3];
int arr2[]=new int[3];

Scanner sc=new Scanner(System.in);

	void input() 
	{
		System.out.println("Enter an Array1 Element : ");	
		
		for(int i=0;i<arr1.length;i++)
		{
			arr1[i]=sc.nextInt();
		}
		
		System.out.println("Enter an Array2 Element : ");	

		for(int i=0;i<arr2.length;i++)
		{
			arr2[i]=sc.nextInt();
		}

		System.out.println("Enter an Array3 Element : ");	

		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	}
	
	void display() 
	{
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");	
		}
		System.out.print("sum show ="+sum);
		
		for(int i=0;i<arr.length;i++)
		{
		arr[i]=arr1[i]+arr2[i];
			System.out.print(arr[i]+" ");	
		}		
            System.out.println();
	}
	public static void main(String[] args)
	{
		ArraySum a=new ArraySum();
		a.input();
		a.display();	
	}
}
