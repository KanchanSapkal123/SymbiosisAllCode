package Array;

import java.util.Scanner;

public class TestArrayStringIn5Element {

	public static void main(String[] args) {
		
		
		char a[]=new char[5] ;
		
		System.out.println("Enter an element ");
		
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<a.length;i++) 
		{
			a[i]=sc.next().charAt(0);
		}
		
		
		System.out.println("Display Arrary");
		for(int i=0;i<a.length;i++) 
		{
			System.out.println(a[i]+"");
		}
	}

}
