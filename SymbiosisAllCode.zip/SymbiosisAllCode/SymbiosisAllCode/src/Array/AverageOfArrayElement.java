package Array;

import java.util.Scanner;

public class AverageOfArrayElement {

	public static void main(String[] args) 
	{
		int avgElement;
		
		int arr[]=new int[5];
		 
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter an Element : ");
		
		
		System.out.println("Enter an average element : ");
		avgElement=sc.nextInt();
		
		for(int i=0;i<arr.length;i++)
		{
			avgElement=avgElement+arr[i];
			
			avgElement=avgElement/arr.length;
			
			System.out.println("Average ="+avgElement);
		}
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		

	}

}
