package Array;

public class CompareTwoArray {

	public static void main(String[] args) {
	
		int a[]= {1,2,3};
		int b[]= {1,3,6};
		
		int l1=a.length;
		int l2=b.length;
		
		if(l1 != l2)
		{
			System.out.println("Array are not equal by length ");
			System.out.println("inside length");
		}
		
		else
		{
			int f=1;
			for(int i=0;i<=a.length;i++)
			{
				if(a[i]!=b[i])
				{
					f=0;
					break;
				}
			}
			if(f==1)
			{
				System.out.println("Array are same by elements");
			}
			else 
			{
				System.out.println("Array are not same by Element");
			}
				
		}
		

	}

}
