package Array;

public class CopyArray 
{
	void input()
	{
		int a[]= { 1,2,3,4,5,6};
		
		
		int b[]=new int[a.length];
		
		for(int i=0;i<=b.length;i++) 
		{	System.out.println(+a[i]);
			System.out.println(+b[i]);
		}	
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		CopyArray c=new CopyArray();                         // hold to solve 
		c.input();

	}

}
