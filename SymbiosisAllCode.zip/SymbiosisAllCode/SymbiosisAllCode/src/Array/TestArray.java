package Array;

public class TestArray {

	public static void main(String[] args) {
	
		
		
		int a[]= {5,4,3,11,12};
		/*
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
		System.out.println(a[4]);
		*/
		for(int i=0;i<5;i++)
		{
			System.out.println(a[i]);
		}

		for(int j=0;j<a.length;j++)
		{
			System.out.println("length="+a[j]);

		}
		
		
		
		
	}

}
