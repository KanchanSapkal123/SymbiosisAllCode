package MamHomework;

import java.util.Scanner;

public class DifferentWayToPrintArray
{

	void array()
	{
		int i;
		
		int a[]=new int[5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array Element : ");
		
		for(i=0;i<=a.length;i++)
		{	
			a[i]=sc.nextInt();
			System.out.println(a[i]);
			
		}	
			
	}
	
	void simpleMethodToPrntArray()
	{
	int	a[]= {1,2,3,4,5,6};
	
	for(int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);	
	}
	}
	
	public static void main(String[] args)
	{
		
		DifferentWayToPrintArray d=new DifferentWayToPrintArray();
		d.array();
	//	d.simpleMethodToPrntArray();

	}

}
