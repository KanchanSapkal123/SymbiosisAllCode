package MamHomework;

import java.util.Scanner;

public class FindSumOfArray 
{	
	int[] input()
	{
		int num[]=new int[5];
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter an Elements");
		
		
		for(int i=0;i<num.length;i++) 
		{
			num[i]=sc.nextInt();
		}
		return num;		
	}
	
	void display(int a[])
	{
		System.out.println("Display Array : ");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]+" ");
		}
	}			
		
	void sum(int num[]) 
	{
		int sum=0;
		for(int i=0;i<num.length;i++)
		{
			sum+=num[i];
		}
		System.out.println("\nsum is : "+sum);
		
	}

	public static void main(String[] args)
	{
	
		FindSumOfArray f=new FindSumOfArray();
		int b[]=f.input();

		f.display(b);
		
		f.sum(b);
       
	}

}
