package MamHomework;

import java.util.Scanner;



public class ReturnArrayMethod {

static int i;
	
	static int array() 
	{
		char a[]=new char[5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array element : ");
		
		for( i=0;i<=a.length;i++)
		{
			a[i]=sc.next().charAt(0);
			
			System.out.println("array element : "+a[i]);
		}
		return a[i];			
	}
	
	
	
	public static void main(String[] args) 
	{
		array();
		
		
		
		
	}

}
