package Solvedproblem;

public class Employee {

	String name;
	Double basic,Da,HRA,Total,pf,netsalary;
	
	Employee()
	{
		name="Ajay";
		basic=(double) 15000;
		
	}
	
	void calcultion() 
	{
		
		Da=basic*45;
		HRA=basic*15;
		pf=basic*8.33;
		Total=basic+Da+HRA;
		netsalary = Total - pf;	
	}
	
	void display()
	{
		System.out.println("name="+name);
		System.out.println("Da="+Da);
		System.out.println("HRA="+HRA);
		System.out.println("pf="+pf);
		System.out.println("Total="+Total);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		e.calcultion();
		e.display();
	}

}
