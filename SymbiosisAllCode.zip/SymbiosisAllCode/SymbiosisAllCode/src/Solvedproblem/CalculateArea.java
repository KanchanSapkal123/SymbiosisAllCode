package Solvedproblem;

class circle
{
	float PI,Area,R;
	circle(float R)
	{
		PI=3.14f;
		this.R=R;
	}
	
	float Area() 
	{
		
		Area =PI*R*R;
		
		
		System.out.println("Area of Circle = "+Area);

		return Area;
		
	}
}

public class CalculateArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		circle c=new circle(2.0f);
		c.Area();
		
		
		
		
	//System.out.println("Area of Circle = "c.Area);
	}

}
