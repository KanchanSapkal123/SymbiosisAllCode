package Solvedproblem;

public class A {

	
	A()
	{
		this(5);		
		System.out.println("Default ");
	}
	
	A(int n1)
	{
		this(5,6);
		System.out.println("Parameter Constructor");
		
	}
	
	A(int n1,int n2)
	{
		
		System.out.println(n1+n2);
		
		
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		A s=new A();
		System.out.println("Finish");

	}

}
