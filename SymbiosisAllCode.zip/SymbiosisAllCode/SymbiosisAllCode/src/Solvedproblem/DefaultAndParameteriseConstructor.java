package Solvedproblem;

public class DefaultAndParameteriseConstructor {

	int n1,n2;
	
	DefaultAndParameteriseConstructor()
	{
		n1=5;
		n2=6;
	}
	
	DefaultAndParameteriseConstructor(int n1)
	{

		this.n1=n1;
		n2=5;
		
	}
	
	DefaultAndParameteriseConstructor(int n,int n2)
	{
		this.n1=n2;
		this.n2=n2;
		
	}
	
	DefaultAndParameteriseConstructor(DefaultAndParameteriseConstructor t)
	{
		n1=t.n1;
		n2=t.n2;
		
	}
	
	void sum()
	{
		System.out.println(n1+n2);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DefaultAndParameteriseConstructor t=new DefaultAndParameteriseConstructor();
		
		t.sum();
		
		DefaultAndParameteriseConstructor t1=new DefaultAndParameteriseConstructor(6);

		t1.sum();
		
		DefaultAndParameteriseConstructor t2=new DefaultAndParameteriseConstructor(8,9);

		t2.sum();
		
		DefaultAndParameteriseConstructor t3=new DefaultAndParameteriseConstructor(t2);

		t3.sum();
		
		
		
	}

}
