package Constructor;

import java.util.Scanner;

public class TestArmstrong
{	
	int countDigit(int n) 
	{		
		int count = 0;
		
		while(n!=0) 
		{			
			count=count + 1;
			n/=10;			
		}
		return count;
	}
		
	int power(int n,int p)
	{
		int result=1;
		for(int i=1;i<=p;i++)
		{
			result=result*n;
		}
		return result;
		
	}

	void Armstrong(int n)
	{
		int m=n;
		int sum=0;
		
		int c=countDigit(n);                         //function la call kel
		
		while(n!=0)
		{
			int d=n%10;
			sum=sum+power(d,c);
			n=n/10;
		}
		
		
//		Void show()
//		{
//		int i=100,arm;
//		System.out.println("Armstrong numbers between 100 to 5000");
//		while(i<5000)
//		{
//		arm=armstrongOrNot(i);
//		if(arm==i)
//		System.out.println(i);
//		i++;
//		}
//		}
//		
//		
//	static int armstrongOrNot(int num)
//	{
//		int x,a=0;
//		while(num!=0)
//		{
//			x=num%10;
//			a=a+(x*x*x);
//			num/=10 ;
//		}
//		return a;
//	
//		
//		
//	}
//		
		if(sum==m)
		{
			System.out.println(m);
	}

		
//			else
//			{
//				System.out.println("Number is not Armstrong");
//		}

}	
	public static void main(String[] args) {
		
		TestArmstrong ob=new TestArmstrong();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter number ");
		int num=sc.nextInt();
		ob.Armstrong(num);
		
		
		/*for(int i=100;i<=5000;i++)
		{
		ob.Armstrong(i);
		}
		*/
		
	}

}


