package Constructor;

//import java.util.Scanner;

public class TestFibonacci
{

	void fibonacci()
	{
		int x=0,y=1;
		System.out.println(x);
		
		for(int i=1;i<=8;i++)
		{
		
		int z=x+y;
		x=y;
		y=z;
		System.out.println(""+z);
		
		}
	}
	public static void main(String[] args)
	{
		TestFibonacci t=new TestFibonacci();
		t.fibonacci();
	}
}
