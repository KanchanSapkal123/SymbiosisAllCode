package Constructor;

import java.util.Scanner;

public class PrimeNumber {

	void isPrime(int n)
	{
		int flag=1;
		
		for(int i=2;i<=n;i++) {
			
			if(n%i==0) {
				flag=0;
				break;
			}			
		}	
		
		if(flag==1)
		{
			System.out.println("This is prime number");
		}else
		{
			System.out.println("This is not prime number");
		}
	}

	public static void main(String[] args)
	{
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter the value n");
	   int n = sc.nextInt();
	
		PrimeNumber p=new PrimeNumber();
		p.isPrime(n);
	
	}

}
