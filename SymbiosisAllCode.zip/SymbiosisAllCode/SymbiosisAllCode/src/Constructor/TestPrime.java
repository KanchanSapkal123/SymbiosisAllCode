package Constructor;


public class TestPrime {

	
	public static void main(String[] args) 
{
		
		
}
}