package Constructor;

import java.util.Scanner;

class constructor{
	
	private int length;
	private int breath;
	private int height;
	
	
		
	constructor(int length,int width ,int height )
	{
		this.length=length;
		this.breath=width;
		this.height=height;
	}
	
	constructor(constructor c)
	{
		length=c.length;
		breath=c.breath;
		height=c.height;
		  
	}
	
//	void input()
//	{
//		System.out.println("Enter the length");
//		length=sc.nextInt();
//		
//		System.out.println("Enter the breath");
//		breath=sc.nextInt();
//	}
//	
	void display()
	{
		int volume=length*breath*height;
		System.out.println("volume="+volume);
	}
}

public class Copy_Constructor {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);

		
		 System.out.println("Enter the length"); int length=sc.nextInt();
		 
		  System.out.println("Enter the breath"); int breath=sc.nextInt();
		 
		 System.out.println("Enter the height"); int height=sc.nextInt();
		

	    
		constructor c=new constructor(length,breath,height);
		//constructor c=new constructor(5,6,7);
	
		c.display();		
		
	}
} t5