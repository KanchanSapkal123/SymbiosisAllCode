package Constructor;

import java.util.Scanner;

class Box
{
    private int length;
	private int breath;
    private	int height;
	
Box()
{
	length =length;
	breath =breath;
	height =height;
}
	
Box(int length,int breath,int height)
	{
		this. length =length;
		  this. breath =breath;
		  this. height =height;	
	}
	
	void findVolume()
   {
	int volume =length*breath*height;
	System.out.println(volume);
   }
}

public class TestConstructor {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter length value : ");
	    int length = sc.nextInt();
	    
	    System.out.println("Enter breath value : ");
	    int breath = sc.nextInt();
	    
	    System.out.println("Enter height value : ");
	    int height = sc.nextInt();
	    
	    
	    Box b=new Box(length,breath,height);
	
         b.findVolume();
          
                
	}
}
