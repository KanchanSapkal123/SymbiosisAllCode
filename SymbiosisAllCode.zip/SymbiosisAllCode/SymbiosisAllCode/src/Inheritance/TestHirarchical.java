package Inheritance;

/*
class vehicle
{
	
	public void displayVehicle()
	{
		System.out.println("Vehicle Class");
	}
	
	
	
}

class TwoWheeler extends vehicle
{
	void showTwoWheeler() {
		System.out.println("Two Wheeler class : ");
	}
	
	
}

class FourWheeler extends vehicle
{
	
	public void printFourWheel() 
	{
		
	System.out.println("Four Wheeler class : ");
	
	}
}




public class TestHirarchical {

	public static void main(String[] args) {
		
		TwoWheeler t=new  TwoWheeler();
		t.showTwoWheeler();
		t.displayVehicle();
		
		FourWheeler f=new FourWheeler();
		f.displayVehicle();
		f.printFourWheel();
		
	}

}
*/