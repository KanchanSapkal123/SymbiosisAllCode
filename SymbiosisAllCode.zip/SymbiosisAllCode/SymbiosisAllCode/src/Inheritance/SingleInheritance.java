package Inheritance;

class Bisycle{
	
	public int gear,speed;
	
	Bisycle(int gear,int speed)
	{
		this.gear=gear;
		this.speed=speed;
		
	}
	
	public void applyBreak(int decrement)
	{
		speed-=decrement;
	}
	
	public void speedUp(int Increment)
	{
		speed+=Increment;
		
	}
	
	
	public String toString()
	{
		return gear + " " +speed;
	}
	
}
	
	class MountainBike extends Bisycle
	{
		public int seatHeight;
		
		
		MountainBike(int gear,int speed,int seatHeight)
	    {
			super(gear,speed);
			this.seatHeight=seatHeight;	
		}
		
		public String toString()
		{
			return super.toString()+" "+seatHeight;
			
		}
	}
	

public class SingleInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		MountainBike mb=new MountainBike(4,50,100);
		System.out.println(mb);
		
		
	/*	Bisycle b=new Bisycle(4,50);
		
		b.applyBreak(3);
		b.speedUp(20);
		
		System.out.println(b);
		*/

	}

}
