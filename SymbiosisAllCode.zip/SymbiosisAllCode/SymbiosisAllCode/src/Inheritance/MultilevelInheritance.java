package Inheritance;

class Vehicle{
	
	public String make,color,model;
	Vehicle(String make2, String color2, String model2)
	{
		this.make=make;
		this.color=color;
		this.model=model;
	}
	
	
	public void printDetails()
	{
		System.out.println("make="+make+" color="+color+"model="+model);
	}
}

class car extends Vehicle{
	
	public String bodyStyle;
	
	car(String make,String color,String model,String bodyStyle)
	{
		super(make,color,model);
		this.bodyStyle = bodyStyle;
		
	}
	
	public void carDetails() 
	{	printDetails();
		//System.out.println(super.toString()+" "+bodyStyle);
	System.out.println(super.toString()+"bodyStyle="+bodyStyle+" \n");
	
	}
	
	
}
	class Maruti800 extends car
	{

public int cost;

		Maruti800(String make, String color, String model, String bodyStyle,int cost) {
			super(make, color, model, bodyStyle);
		
			this.cost=cost;
			
		}
		public void show()
		{
			carDetails();
			System.out.println("cost="+cost);
			
		}
	}
	
	
	



public class MultilevelInheritance {

	public static void main(String[] args) {
	
		Maruti800 m=new Maruti800("maruti","grey","Maruti 800","sedan",500000);
		
		m.show();

	}

}
