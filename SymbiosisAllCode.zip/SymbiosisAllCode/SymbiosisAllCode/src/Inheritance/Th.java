package Inheritance;
class veh
{
	
	public void displayVehicle()
	{
		System.out.println("Vehicle Class");
	}
	
	
	
}

class TwoWheeler extends veh
{
	void showTwoWheeler() {
		System.out.println("Two Wheeler class : ");
	}
	
	
}

class FourWheeler extends veh
{
	
	public void printFourWheel() 
	{
		
	System.out.println("Four Wheeler class : ");
	
	}
}



public class Th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		TwoWheeler t=new  TwoWheeler();
		t.showTwoWheeler();
		t.displayVehicle();
		
		FourWheeler f=new FourWheeler();
		f.displayVehicle();
		f.printFourWheel();
		

	}

}
