package DoWhile_break_continue;

public class For_break {

	public static void main(String[] args)
	{
		
		for(int i=1;i<=5;i++)
		{
			if(i==3)
	        {
				break;
		 }
             System.out.println(i);
		}
			System.out.println("out of loop");
	}

	
	}
	
	

