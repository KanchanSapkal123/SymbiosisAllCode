package DoWhile_break_continue;

import java.util.Scanner;

public class PowerOfNumber {

	private int num,exp;
	
	Scanner sc=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("Enter number : ");
		num=sc.nextInt();
		
		System.out.println("Enter power of number : ");
		exp=sc.nextInt();
	}
	
	public int power()
	{
		int result =1;
		for(int i=1;i<=exp;i++) 
			
		result*=num;
		
		return result;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PowerOfNumber ob=new PowerOfNumber();
		
		Scanner sc=new Scanner(System.in);
		
		String s;
		
		
		do {
			System.out.println("1.call input function");
			System.out.println("1.call power function");

			int ch;
			
			System.out.println("Enter your choice : ");
			ch=sc.nextInt();
			
			switch(ch) 
			{
			case 1 :
				ob.input();
				//break;
				
			case 2 :
				int p=ob.power();
				System.out.println("Power is : "+p);
				break;
				
			default :
				System.out.println("your choice is wrong ");
			    }
			
			System.out.println("Do you want to continue : 'y' or 'n'");
			s=sc.next();
			
		     }
		
		    while(s.equals("y"));
		
		System.out.println("program exist");	
	}

}