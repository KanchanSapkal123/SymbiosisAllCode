package DoWhile_break_continue;

import java.util.Scanner;

public class TestPallindrom {

	
		int revNum(int num)
	{
		int rev=0;
		
		while(num!=0)
		{
			rev=num%10+rev*10;
			num=num/10;
		}
		return rev;
		
	}	

		void pallin(int num)
		{
		int rev=revNum(num);
			
			if(rev==num)
			
				System.out.println("Number is pallindrom");
			
		
		else
				System.out.println("Number is not pallindrom");
	}
			
	public static void main(String[] arg)
	{
             TestPallindrom ob=new TestPallindrom();
             Scanner sc=new Scanner(System.in);
             
             System.out.println("Enter number");
             int num=sc.nextInt();
             
             
            ob.pallin(num);
             
	}

}
