package DoWhile_break_continue;

import java.util.Scanner;

public class Testclass {

	public static void main(String[] args) {   //self program creativetity
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int ch;
		String s = null;
		int num1 = 0,num2 = 0,sum;
		do
		{
			System.out.println("Enter num1 : ");
			num1=sc.nextInt();
			
			System.out.println(" Enter num2 : ");
			num1=sc.nextInt();
			
		   System.out.println("Enter your choice : ");	
		   ch=sc.nextInt();
		
		switch(ch)
		{
		
		case 1 : sum=num1+num2;
			System.out.println("sum of two number : " +sum);
			break;
			
		case 2 : sum=num1*num2;
		System.out.println("sum of two number : " +sum);
		break;
		
		
		case 3 : sum=num1-num2;
		System.out.println("sum of two number : " +sum);
		break;
		
		case 4 : sum=num1/num2;
		System.out.println("sum of two number : " +sum);
		break;
		
		}
		
		}
	while(s.equals("y"));
		System.out.println("program is exist");
	}

}    
