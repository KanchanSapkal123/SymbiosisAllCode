
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
				//String rString = "";
				String str = "kanchan";
				int n = str.length();
				char ch;
				for (int i = 0; i < str.length(); i++) 
				{
					ch = str.charAt(i);
				//	rString = ch + rString;
				}
				//System.out.println(rString);
			
			
				StringBuilder builder =new StringBuilder();
				builder.append(str);
				
				
				builder.reverse();
				System.out.println(builder);
			}
			
		
	}


