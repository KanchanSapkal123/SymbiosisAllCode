package ControllStatement;

import java.util.Scanner;

class TestTwoNumber
{
	
	int num;
	
	Scanner sc=new Scanner(System.in);
	
	void input() {
		
	System.out.println("Enter number : ");
	num=sc.nextInt();
	
	}
	
	void CheckNumber() 
	{
		if(num>0)
		{
			System.out.println("Number is positive : ");
		}
		else
		{
			System.out.println("number is negative : ");
		}
	}
}

public class IfElse {

	public static void main(String[] args) {
	
		TestTwoNumber t=new TestTwoNumber();
		
		t.input();
		t.CheckNumber();
		
	}



	
}