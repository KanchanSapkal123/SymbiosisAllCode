package ControllStatement;

import java.util.Scanner;


class TestSwitch
{
	int day;
	
	Scanner sc=new Scanner(System.in);

	void input()
	{
	System.out.println(" Enter the day : ");
	day=sc.nextInt();
	}
	
	
	void checkCondition()
	{
		switch(day)
		{
		
		
		case 1:
			System.out.println("monday");
			break;
			
		case 2:
			System.out.println("tuesday");
			break;
		
		case 3:
			System.out.println("wensday");
			break;
		
		case 4:
			System.out.println("thusday");
			break;
		
		case 5:
			System.out.println("friday");
			break;
		
		case 6:
			System.out.println("saterday");
			break;
		
		case 7:
			System.out.println("sunday");
			break;
		
		}
	}
}

public class Switch {

	public static void main(String[] args) {
		
		TestSwitch t=new TestSwitch();
		t.input();
		t.checkCondition();

		
		
	}
}
