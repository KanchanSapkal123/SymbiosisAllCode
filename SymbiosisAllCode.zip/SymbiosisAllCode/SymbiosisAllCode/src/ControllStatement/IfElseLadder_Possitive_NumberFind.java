package ControllStatement;

import java.util.Scanner;


class Test{
	 
	int num;
	Scanner sc=new Scanner(System.in);
	
	void input()
	{
	System.out.println("Enter the number");
	num=sc.nextInt();

	}
	
	void findNumber() 
	{
		if(num>0)
		{
			System.out.println("This is number is positive");
		}
		else if(num<0)
		{
			System.out.println("This number is negative");
		}
		else
		{
			System.out.println("This number is Zero");

		}
		
	}

}

public class IfElseLadder_Possitive_NumberFind {

	public static void main(String[] args) {
	
           
		Test t=new Test();
		
		t.input();
		t.findNumber();
	
	}
}


