package ControllStatement;

import java.util.Scanner;

class addition{
	char ch;
	
	int num1,num2,result;
	
	
	Scanner sc=new Scanner(System.in);
	
	void input(	)
	{
		System.out.println("Enter num1");
		num1=sc.nextInt();
		
		System.out.println("Enter num1");
		num2=sc.nextInt();
		
		System.out.println("Enter char");
		ch=sc.next().charAt(0);
	}
	
	void checkCondition() 
	{	
		switch(ch)
		{
		case '+' : result=num1+num2;
	        System.out.println("result : "+result);
		    break;
		
		case '-' :result=num1-num2;
		    System.out.println("result : "+result);
			break;
			
		
		case '*' :result=num1*num2;
		    System.out.println("result : "+result);
			break;
			
		case '/' :result=num1/num2;
		    System.out.println("result : "+result);
			break;
		}
	}
}

public class TestSwitchcase
{

	public static void main(String[] args)
	{
	
		addition a=new addition();
				a.input();
		        a.checkCondition();
	}

}
