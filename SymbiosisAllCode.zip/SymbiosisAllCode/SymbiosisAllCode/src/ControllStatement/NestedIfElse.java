package ControllStatement;

import java.util.Scanner;

class TestNumber{
	
	int num1,num2,num3;
	
	Scanner sc=new Scanner(System.in);
	
	void input() {
		
		System.out.println("Enter the number first");
		num1=sc.nextInt();
		
		System.out.println("Enter the number second");
		num2=sc.nextInt();
		
		System.out.println("Enter the number third");
		num3=sc.nextInt();
	}
	
	
	
	void findMax() {
		if(num1>num2)
		{
			 if(num1>num3)
			 {
				 System.out.println(+num1 +" "+"This is gretest number");
			 }
			 else
			 {
				 System.out.println(+num3 +" "+ "This is gretest number");
				 
			 }
		}
		else
		{
			 if(num1>num3)
			 {
				 System.out.println(+num2 +" "+" This is gretest number");
			 }
			 else
			 {
				 System.out.println(+num3 +" "+" This is gretest number");
			 }
			
		}  
	}
}
public class NestedIfElse {

	public static void main(String[] args) {
	
		TestNumber t=new TestNumber();
		t.input();
		t.findMax();

	}

}
