package ControllStatement;

import java.util.Scanner;

/*
 * public class ForLoop {
 * 
 * public static void main(String[] args) {
 * 
 * for(int i=1;i<11;i++) { System.out.println(i); }
 * 
 * }
 * 
 * }
 */

public class ForLoop {
	 
	 public static void main(String[] args) {
	 int sum = 0;
	 Scanner sc = new Scanner(System.in);
	 System.out.println("enter 5 number ");
	 for(int i=1;i<=5;i++) 
	 { 
		 
		 int num = sc.nextInt();
		 sum+=num;
		// System.out.println(sum);
	}
	 System.out.println(" Sum is "+sum);
	 }
}
