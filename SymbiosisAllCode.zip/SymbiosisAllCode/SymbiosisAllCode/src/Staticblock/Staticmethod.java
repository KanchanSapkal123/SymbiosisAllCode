package Staticblock;


class TestStatic
{
	
	static int a=10;
	static int b;
	
	
	//static block
	
	static
	{
		System.out.println("static block initialize");
		
		b=a*4;
	}
	
	
	
	
	
}
public class Staticmethod {

	public static void main(String[] args) {
		
		
		
		
		
		
		

	}

}
