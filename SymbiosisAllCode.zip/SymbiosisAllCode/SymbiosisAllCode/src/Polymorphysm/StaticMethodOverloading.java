package Polymorphysm;


class Adder
{
	
	static void add(int a,int b) 
	{
		System.out.println(a+b);
		
	}
	
	static void add(int a,int b,int c)
	{
		System.out.println("From"+a+b+c);
		
	}	
	
	  
	
	
	
}
public class StaticMethodOverloading {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Adder a=new Adder();
		a.add(4,5);
		a.add(3, 5,9);
		
	}

	
	}

}
