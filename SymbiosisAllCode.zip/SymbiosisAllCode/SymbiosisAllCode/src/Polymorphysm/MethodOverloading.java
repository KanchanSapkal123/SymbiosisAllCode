package Polymorphysm;

public class MethodOverloading {

	void input(String name) 
	{	
		System.out.println(name);	
	}
	
	void input() {
		int a=123;
		System.out.println(a);
	}
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloading m=new MethodOverloading();
		
		m.input("kanchan");
		m.input();
		
		
	}

}
