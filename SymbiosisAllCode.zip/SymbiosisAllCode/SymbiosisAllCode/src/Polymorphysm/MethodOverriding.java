package Polymorphysm;


  class vehicle
{
	 void display() {
		System.out.println("This is vehicle class");
	}
}


class car extends vehicle
{
	void display() {
		super.display();
		System.out.println("This is car class");
	}
}
public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		car c=new car();
		c.display();
		//c.display();
	}

}
