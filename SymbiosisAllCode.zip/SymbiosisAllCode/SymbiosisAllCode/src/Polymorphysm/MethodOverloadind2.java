package Polymorphysm;

public class MethodOverloadind2 {

	
	void area(double r)
	{
	double area1=3.14*r*r;
	
	System.out.println(area1);
	}
	
	void area(float s)
	{
		float Squer=s*s;
		
		System.out.println(Squer);
	}
	
	void area(int x,int y)
	{
		double areaofrectangle=x*y;
		System.out.println(areaofrectangle);
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloadind2 m=new MethodOverloadind2();
		
		m.area(5);
		m.area(2);
		m.area(4,6);
	}

}
