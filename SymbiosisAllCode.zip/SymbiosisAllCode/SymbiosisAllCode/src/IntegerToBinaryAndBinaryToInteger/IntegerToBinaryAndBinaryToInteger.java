package IntegerToBinaryAndBinaryToInteger;

public class IntegerToBinaryAndBinaryToInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
				
		int num1=5;

		   System.out.println("binary="+Integer.toBinaryString(num1));                   //this is converted integer to binary Number
				
			String first="101";
			
			int num=Integer.parseInt(first,2);                                          //this is converted Binary to Integer
				
			System.out.println("Binary to Integer ="+num);
				
			
		
	}

}
